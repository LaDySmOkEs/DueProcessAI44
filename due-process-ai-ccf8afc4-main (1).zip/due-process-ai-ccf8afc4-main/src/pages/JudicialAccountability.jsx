import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { InvokeLLM } from "@/api/integrations";
import { Gavel, Search, Loader2, AlertTriangle, ExternalLink, Scale, FileText, Eye } from "lucide-react";

const judicialSearchSchema = {
    type: "object",
    properties: {
        judge_found: {
            type: "boolean",
            description: "Whether any disciplinary or accountability information was found for this judge"
        },
        summary: {
            type: "string",
            description: "Overall summary of the judge's disciplinary record and accountability issues"
        },
        disciplinary_actions: {
            type: "array",
            items: {
                type: "object",
                properties: {
                    date: { type: "string", description: "Date of disciplinary action" },
                    issuing_body: { type: "string", description: "Which judicial conduct board or authority issued the discipline" },
                    violation_type: { type: "string", description: "Type of misconduct (bias, financial conflicts, inappropriate conduct, etc.)" },
                    penalty: { type: "string", description: "Penalty imposed (censure, suspension, fine, etc.)" },
                    details: { type: "string", description: "Detailed description of the misconduct" },
                    case_impact: { type: "string", description: "Whether this affected specific cases or rulings" }
                }
            },
            description: "Official disciplinary actions taken against the judge"
        },
        ethics_violations: {
            type: "array",
            items: {
                type: "object",
                properties: {
                    violation_category: { type: "string", description: "Category of ethics violation" },
                    description: { type: "string", description: "Description of the ethics violation" },
                    resolution: { type: "string", description: "How the violation was resolved" },
                    ongoing_impact: { type: "string", description: "Whether this impacts current cases" }
                }
            },
            description: "Ethics violations and conflicts of interest"
        },
        controversial_rulings: {
            type: "array",
            items: {
                type: "object",
                properties: {
                    case_name: { type: "string", description: "Name or identifier of the case" },
                    date: { type: "string", description: "Date of the ruling" },
                    controversy: { type: "string", description: "What made this ruling controversial" },
                    appeals_outcome: { type: "string", description: "Whether the ruling was overturned on appeal" },
                    legal_criticism: { type: "string", description: "Legal community criticism of the ruling" }
                }
            },
            description: "Controversial rulings that may indicate bias or poor judgment"
        },
        financial_disclosures: {
            type: "array",
            items: {
                type: "object",
                properties: {
                    disclosure_year: { type: "string" },
                    potential_conflicts: { type: "string", description: "Potential conflicts of interest from financial holdings" },
                    recusal_patterns: { type: "string", description: "Pattern of recusals or failure to recuse" }
                }
            },
            description: "Financial disclosure issues and potential conflicts"
        },
        bias_indicators: {
            type: "array",
            items: {
                type: "object",
                properties: {
                    bias_type: { type: "string", description: "Type of potential bias (racial, political, economic, etc.)" },
                    evidence: { type: "string", description: "Evidence or allegations of bias" },
                    impact_on_cases: { type: "string", description: "How this bias may affect case outcomes" }
                }
            },
            description: "Indicators of judicial bias that could affect fair proceedings"
        },
        accountability_score: {
            type: "string",
            enum: ["Excellent", "Good", "Concerning", "Poor", "Severely Compromised"],
            description: "Overall assessment of judicial accountability and fitness"
        }
    },
    required: ["judge_found", "summary", "accountability_score"]
};

export default function JudicialAccountability() {
    const [searchData, setSearchData] = useState({
        judge_name: "",
        court_name: "",
        jurisdiction: ""
    });
    const [results, setResults] = useState(null);
    const [isSearching, setIsSearching] = useState(false);
    const [error, setError] = useState(null);

    const handleSearch = async () => {
        if (!searchData.judge_name && !searchData.court_name) {
            setError("Please provide either a judge's name or court name to search.");
            return;
        }
        
        setIsSearching(true);
        setError(null);
        setResults(null);

        try {
            const prompt = `Conduct a comprehensive judicial accountability investigation for: 
            Judge Name: "${searchData.judge_name}"
            Court: "${searchData.court_name}" 
            Jurisdiction: "${searchData.jurisdiction}"

            Search all available public records for:

            1. DISCIPLINARY ACTIONS:
            - Official reprimands, censures, suspensions
            - Judicial conduct commission findings
            - Bar disciplinary actions
            - Ethics violations and sanctions

            2. CONTROVERSIAL RULINGS:
            - Rulings overturned for bias or error
            - Patterns of unusual sentencing
            - Civil rights violations in rulings
            - Legal community criticism

            3. FINANCIAL CONFLICTS:
            - Financial disclosure violations
            - Conflicts of interest in cases
            - Failure to recuse when required
            - Business relationships affecting cases

            4. BIAS INDICATORS:
            - Discriminatory language or behavior
            - Patterns favoring certain parties
            - Political bias in rulings
            - Inappropriate relationships

            5. ACCOUNTABILITY ISSUES:
            - Refusal to follow procedural rules
            - Denial of due process rights
            - Arbitrary or capricious decisions
            - Abuse of judicial power

            Focus on factual, verifiable information from judicial conduct boards, appellate court decisions, news reports, and legal publications. Cite specific sources where possible.`;

            const result = await InvokeLLM({
                prompt: prompt,
                add_context_from_internet: true,
                response_json_schema: judicialSearchSchema
            });

            setResults(result);
        } catch (err) {
            console.error("Judicial search error:", err);
            setError("Search failed. Please try again or check your internet connection.");
        } finally {
            setIsSearching(false);
        }
    };

    const getAccountabilityColor = (score) => {
        switch (score?.toLowerCase()) {
            case 'excellent': return 'bg-green-100 text-green-800 border-green-200';
            case 'good': return 'bg-blue-100 text-blue-800 border-blue-200';
            case 'concerning': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
            case 'poor': return 'bg-orange-100 text-orange-800 border-orange-200';
            case 'severely compromised': return 'bg-red-100 text-red-800 border-red-200';
            default: return 'bg-slate-100 text-slate-800 border-slate-200';
        }
    };

    return (
        <div className="p-6 space-y-8">
            <div className="max-w-6xl mx-auto">
                {/* Header */}
                <div className="mb-8">
                    <div className="flex items-center gap-3 mb-4">
                        <div className="w-12 h-12 bg-gradient-to-br from-slate-800 to-slate-900 rounded-xl flex items-center justify-center">
                            <Gavel className="w-7 h-7 text-white" />
                        </div>
                        <div>
                            <h1 className="text-3xl font-bold text-slate-900">Judicial Accountability Tracker</h1>
                            <p className="text-slate-600 mt-1">Research judicial discipline records, ethics violations, and accountability issues</p>
                        </div>
                    </div>
                    
                    <div className="bg-slate-900 border border-slate-700 rounded-lg p-4 mb-6">
                        <h2 className="font-semibold text-white mb-2 flex items-center gap-2">
                            <Scale className="w-5 h-5"/> Why Judicial Accountability Matters
                        </h2>
                        <p className="text-slate-300 text-sm leading-relaxed">
                            Judges wield enormous power over people's lives, liberty, and property. When judges are compromised by bias, financial conflicts, or ethical violations, the entire system of due process breaks down. This tool helps you research whether the judge in your case has a history of misconduct that could affect fair proceedings.
                        </p>
                    </div>
                </div>

                {/* Search Interface */}
                <Card className="border-0 shadow-lg bg-white mb-6">
                    <CardHeader>
                        <CardTitle>Research Judicial Records</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                            <Input 
                                placeholder="Judge Name (e.g., Hon. John Smith)" 
                                value={searchData.judge_name}
                                onChange={(e) => setSearchData({...searchData, judge_name: e.target.value})}
                            />
                            <Input 
                                placeholder="Court Name (e.g., Superior Court)" 
                                value={searchData.court_name}
                                onChange={(e) => setSearchData({...searchData, court_name: e.target.value})}
                            />
                            <Input 
                                placeholder="Jurisdiction (e.g., Los Angeles County)" 
                                value={searchData.jurisdiction}
                                onChange={(e) => setSearchData({...searchData, jurisdiction: e.target.value})}
                            />
                        </div>
                        
                        <Button 
                            onClick={handleSearch} 
                            disabled={isSearching}
                            className="bg-slate-800 hover:bg-slate-900 gap-2"
                        >
                            {isSearching ? (
                                <><Loader2 className="w-4 h-4 animate-spin" /> Investigating...</>
                            ) : (
                                <><Search className="w-4 h-4" /> Research Judge</>
                            )}
                        </Button>

                        {error && (
                            <Alert variant="destructive">
                                <AlertTriangle className="h-4 w-4" />
                                <AlertDescription>{error}</AlertDescription>
                            </Alert>
                        )}
                    </CardContent>
                </Card>

                {/* Results */}
                {results && (
                    <div className="space-y-6">
                        {/* Summary */}
                        <Card className="border-0 shadow-lg bg-white">
                            <CardHeader>
                                <div className="flex justify-between items-start">
                                    <CardTitle>Judicial Accountability Summary</CardTitle>
                                    <Badge className={`${getAccountabilityColor(results.accountability_score)} border`}>
                                        {results.accountability_score} Record
                                    </Badge>
                                </div>
                            </CardHeader>
                            <CardContent>
                                {!results.judge_found ? (
                                    <div className="text-center py-8">
                                        <Eye className="w-12 h-12 text-slate-400 mx-auto mb-4" />
                                        <h3 className="text-lg font-semibold text-slate-900 mb-2">No Disciplinary Records Found</h3>
                                        <p className="text-slate-600">No publicly available disciplinary actions or accountability issues were found for this judge.</p>
                                    </div>
                                ) : (
                                    <div>
                                        <h3 className="font-semibold text-slate-900 mb-2">Investigation Summary</h3>
                                        <p className="text-slate-700 bg-slate-50 p-4 rounded-lg">{results.summary}</p>
                                    </div>
                                )}
                            </CardContent>
                        </Card>

                        {/* Disciplinary Actions */}
                        {results.disciplinary_actions && results.disciplinary_actions.length > 0 && (
                            <Card className="border-0 shadow-lg bg-white">
                                <CardHeader>
                                    <CardTitle className="flex items-center gap-2 text-red-700">
                                        <AlertTriangle className="w-5 h-5" />
                                        Official Disciplinary Actions
                                    </CardTitle>
                                </CardHeader>
                                <CardContent>
                                    <div className="space-y-4">
                                        {results.disciplinary_actions.map((action, index) => (
                                            <div key={index} className="p-4 bg-red-50 border border-red-200 rounded-lg">
                                                <div className="flex justify-between items-start mb-2">
                                                    <h4 className="font-semibold text-red-900">{action.violation_type}</h4>
                                                    <Badge className="bg-red-100 text-red-800">{action.penalty}</Badge>
                                                </div>
                                                <div className="text-sm text-red-700 mb-2">
                                                    {action.issuing_body} • {action.date}
                                                </div>
                                                <p className="text-sm text-red-800 mb-2">{action.details}</p>
                                                {action.case_impact && (
                                                    <div className="bg-red-100 p-2 rounded text-xs text-red-900">
                                                        <strong>Case Impact:</strong> {action.case_impact}
                                                    </div>
                                                )}
                                            </div>
                                        ))}
                                    </div>
                                </CardContent>
                            </Card>
                        )}

                        {/* Bias Indicators */}
                        {results.bias_indicators && results.bias_indicators.length > 0 && (
                            <Card className="border-0 shadow-lg bg-white">
                                <CardHeader>
                                    <CardTitle className="flex items-center gap-2 text-orange-700">
                                        <Scale className="w-5 h-5" />
                                        Potential Bias Indicators
                                    </CardTitle>
                                </CardHeader>
                                <CardContent>
                                    <div className="space-y-4">
                                        {results.bias_indicators.map((bias, index) => (
                                            <div key={index} className="p-4 bg-orange-50 border border-orange-200 rounded-lg">
                                                <h4 className="font-semibold text-orange-900 mb-2">{bias.bias_type} Bias</h4>
                                                <p className="text-sm text-orange-800 mb-2">{bias.evidence}</p>
                                                <div className="bg-orange-100 p-2 rounded text-xs text-orange-900">
                                                    <strong>Potential Impact:</strong> {bias.impact_on_cases}
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                </CardContent>
                            </Card>
                        )}

                        {/* Controversial Rulings */}
                        {results.controversial_rulings && results.controversial_rulings.length > 0 && (
                            <Card className="border-0 shadow-lg bg-white">
                                <CardHeader>
                                    <CardTitle className="flex items-center gap-2 text-purple-700">
                                        <FileText className="w-5 h-5" />
                                        Controversial Rulings
                                    </CardTitle>
                                </CardHeader>
                                <CardContent>
                                    <div className="space-y-4">
                                        {results.controversial_rulings.map((ruling, index) => (
                                            <div key={index} className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
                                                <h4 className="font-semibold text-purple-900">{ruling.case_name}</h4>
                                                <div className="text-sm text-purple-700 mb-2">{ruling.date}</div>
                                                <p className="text-sm text-purple-800 mb-2">{ruling.controversy}</p>
                                                {ruling.appeals_outcome && (
                                                    <div className="bg-purple-100 p-2 rounded text-xs text-purple-900 mb-2">
                                                        <strong>Appeals Outcome:</strong> {ruling.appeals_outcome}
                                                    </div>
                                                )}
                                                {ruling.legal_criticism && (
                                                    <div className="bg-purple-100 p-2 rounded text-xs text-purple-900">
                                                        <strong>Legal Criticism:</strong> {ruling.legal_criticism}
                                                    </div>
                                                )}
                                            </div>
                                        ))}
                                    </div>
                                </CardContent>
                            </Card>
                        )}
                    </div>
                )}
            </div>
        </div>
    );
}
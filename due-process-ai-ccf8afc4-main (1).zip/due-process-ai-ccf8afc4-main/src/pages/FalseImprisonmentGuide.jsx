import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Gavel, 
  AlertTriangle, 
  Shield, 
  BookOpen, 
  Scale, 
  FileText, 
  Clock, 
  Users,
  CheckCircle,
  Info
} from 'lucide-react';
import { InvokeLLM } from "@/api/integrations";
import { useToast } from "@/components/ui/use-toast";
import ReactMarkdown from 'react-markdown';

const falseImprisonmentElements = [
  {
    element: "Intent to Confine",
    description: "The defendant must have acted with the purpose of confining the plaintiff or with knowledge that confinement was substantially certain to result.",
    examples: ["Officer deliberately blocking exit", "Threatening arrest without legal basis", "Creating false sense of legal obligation to stay"]
  },
  {
    element: "Actual Confinement",
    description: "The plaintiff must have been actually confined within boundaries set by the defendant.",
    examples: ["Physical restraint", "Locked in vehicle or room", "Under credible threat of force", "False arrest situation"]
  },
  {
    element: "Awareness of Confinement",
    description: "The plaintiff must have been aware of the confinement or have been harmed by it.",
    examples: ["Knowing you cannot leave", "Being told you're under arrest", "Feeling threatened if you try to leave"]
  },
  {
    element: "Lack of Legal Justification",
    description: "The confinement must be without legal privilege, consent, or other lawful authority.",
    examples: ["No probable cause for arrest", "Exceeding scope of lawful detention", "Continuing detention after legal basis ends"]
  }
];

const commonScenarios = [
  {
    title: "Unlawful Traffic Stop Extension",
    description: "Officer extends traffic stop beyond reasonable time without reasonable suspicion of additional crimes.",
    legalBasis: "Rodriguez v. United States (2015) - Traffic stops cannot be extended beyond time reasonably required for the mission of the stop."
  },
  {
    title: "False Arrest Without Probable Cause",
    description: "Arrest made without sufficient evidence or legal justification.",
    legalBasis: "4th Amendment protection against unreasonable seizures. Probable cause required for lawful arrest."
  },
  {
    title: "Coercive Police Interrogation",
    description: "Creating atmosphere where reasonable person would not feel free to leave during questioning.",
    legalBasis: "Miranda v. Arizona and Terry v. Ohio - Custodial interrogation requires warnings; investigative stops must be brief."
  },
  {
    title: "Detention Beyond Lawful Purpose",
    description: "Continuing to hold someone after the original lawful reason for detention has ended.",
    legalBasis: "Pennsylvania v. Mimms and Terry v. Ohio - Detention must be reasonably related in scope to circumstances justifying it."
  }
];

const legalRemedies = [
  {
    type: "Civil Rights Lawsuit (42 U.S.C. § 1983)",
    description: "Federal lawsuit against government officials for constitutional violations",
    damages: ["Compensatory damages", "Punitive damages", "Attorney's fees", "Injunctive relief"]
  },
  {
    type: "State Tort Claims",
    description: "State law claims for false imprisonment, intentional infliction of emotional distress",
    damages: ["Actual damages", "Pain and suffering", "Lost wages", "Punitive damages"]
  },
  {
    type: "Suppression of Evidence",
    description: "Criminal defense remedy to exclude illegally obtained evidence",
    damages: ["Evidence suppressed", "Charges potentially dismissed", "Plea leverage"]
  }
];

export default function FalseImprisonmentGuide() {
  const [userScenario, setUserScenario] = useState('');
  const [analysis, setAnalysis] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const { toast } = useToast();

  const analyzeScenario = async () => {
    if (!userScenario.trim()) {
      toast({
        title: "Please describe your situation",
        description: "Enter details about your potential false imprisonment case.",
        variant: "destructive"
      });
      return;
    }

    setIsAnalyzing(true);
    setAnalysis('');

    try {
      const prompt = `
        Analyze this potential false imprisonment scenario for legal merit:

        "${userScenario}"

        Please provide:
        1. Whether the four elements of false imprisonment appear to be met
        2. Potential legal claims and remedies available
        3. Strength of the case and key evidence needed
        4. Recommended next steps
        5. Relevant case law or statutes

        Format your response in clear sections with legal analysis.
      `;

      const result = await InvokeLLM({ prompt });
      setAnalysis(result);
      
      toast({
        title: "Analysis Complete",
        description: "Your scenario has been analyzed for false imprisonment elements."
      });
    } catch (error) {
      console.error("Analysis failed:", error);
      toast({
        title: "Analysis Failed",
        description: "Could not analyze scenario. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsAnalyzing(false);
    }
  };

  return (
    <div className="p-6 space-y-8">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 bg-gradient-to-br from-red-600 to-slate-800 rounded-xl flex items-center justify-center">
              <Scale className="w-7 h-7 text-white" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-slate-900">False Imprisonment: A Legal Guide</h1>
              <p className="text-slate-600 mt-1">Understanding your rights when unlawfully detained or confined</p>
            </div>
          </div>
          
          <Alert className="bg-red-50 border-red-200">
            <AlertTriangle className="h-4 w-4 text-red-600" />
            <AlertDescription className="text-red-800">
              <strong>Constitutional Protection:</strong> The 4th Amendment protects against unreasonable seizures. 
              Any detention without legal justification may constitute false imprisonment and violate your constitutional rights.
            </AlertDescription>
          </Alert>
        </div>

        <Tabs defaultValue="elements" className="space-y-6">
          <TabsList className="grid w-full grid-cols-5 bg-white border border-slate-200">
            <TabsTrigger value="elements" className="gap-2">
              <BookOpen className="w-4 h-4" />
              Elements
            </TabsTrigger>
            <TabsTrigger value="scenarios" className="gap-2">
              <Users className="w-4 h-4" />
              Scenarios
            </TabsTrigger>
            <TabsTrigger value="remedies" className="gap-2">
              <Gavel className="w-4 h-4" />
              Remedies
            </TabsTrigger>
            <TabsTrigger value="analyzer" className="gap-2">
              <FileText className="w-4 h-4" />
              Case Analyzer
            </TabsTrigger>
            <TabsTrigger value="resources" className="gap-2">
              <Info className="w-4 h-4" />
              Resources
            </TabsTrigger>
          </TabsList>

          {/* Elements Tab */}
          <TabsContent value="elements" className="space-y-6">
            <Card className="border-0 shadow-lg bg-white">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Shield className="w-5 h-5 text-blue-600" />
                  Four Essential Elements of False Imprisonment
                </CardTitle>
                <p className="text-slate-600 text-sm">All four elements must be present to establish a false imprisonment claim</p>
              </CardHeader>
              <CardContent>
                <div className="grid gap-6">
                  {falseImprisonmentElements.map((element, index) => (
                    <Card key={index} className="border border-slate-200">
                      <CardHeader className="pb-3">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                            <span className="text-blue-600 font-bold text-sm">{index + 1}</span>
                          </div>
                          <CardTitle className="text-lg">{element.element}</CardTitle>
                        </div>
                      </CardHeader>
                      <CardContent className="pt-0">
                        <p className="text-slate-700 mb-4">{element.description}</p>
                        <div>
                          <h4 className="font-semibold text-slate-900 mb-2">Examples:</h4>
                          <ul className="space-y-1">
                            {element.examples.map((example, i) => (
                              <li key={i} className="flex items-start gap-2 text-sm text-slate-600">
                                <CheckCircle className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                                <span>{example}</span>
                              </li>
                            ))}
                          </ul>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Scenarios Tab */}
          <TabsContent value="scenarios" className="space-y-6">
            <Card className="border-0 shadow-lg bg-white">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="w-5 h-5 text-purple-600" />
                  Common False Imprisonment Scenarios
                </CardTitle>
                <p className="text-slate-600 text-sm">Real-world situations where false imprisonment commonly occurs</p>
              </CardHeader>
              <CardContent>
                <div className="grid gap-6">
                  {commonScenarios.map((scenario, index) => (
                    <Card key={index} className="border border-slate-200">
                      <CardHeader>
                        <CardTitle className="text-lg text-slate-900">{scenario.title}</CardTitle>
                        <Badge variant="outline" className="w-fit">
                          Constitutional Issue
                        </Badge>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        <p className="text-slate-700">{scenario.description}</p>
                        <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
                          <h4 className="font-semibold text-blue-900 mb-2">Legal Foundation:</h4>
                          <p className="text-blue-800 text-sm">{scenario.legalBasis}</p>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Remedies Tab */}
          <TabsContent value="remedies" className="space-y-6">
            <Card className="border-0 shadow-lg bg-white">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Gavel className="w-5 h-5 text-green-600" />
                  Legal Remedies & Damages
                </CardTitle>
                <p className="text-slate-600 text-sm">Available legal actions and potential compensation for false imprisonment</p>
              </CardHeader>
              <CardContent>
                <div className="grid gap-6">
                  {legalRemedies.map((remedy, index) => (
                    <Card key={index} className="border border-slate-200">
                      <CardHeader>
                        <CardTitle className="text-lg text-slate-900">{remedy.type}</CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        <p className="text-slate-700">{remedy.description}</p>
                        <div>
                          <h4 className="font-semibold text-slate-900 mb-2">Potential Damages:</h4>
                          <ul className="grid grid-cols-2 gap-2">
                            {remedy.damages.map((damage, i) => (
                              <li key={i} className="flex items-center gap-2 text-sm text-slate-600">
                                <CheckCircle className="w-4 h-4 text-green-600 flex-shrink-0" />
                                <span>{damage}</span>
                              </li>
                            ))}
                          </ul>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Case Analyzer Tab */}
          <TabsContent value="analyzer" className="space-y-6">
            <Card className="border-0 shadow-lg bg-white">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <FileText className="w-5 h-5 text-amber-600" />
                  AI Case Analyzer
                </CardTitle>
                <p className="text-slate-600 text-sm">Get an AI analysis of your potential false imprisonment case</p>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">
                    Describe Your Situation
                  </label>
                  <Textarea
                    placeholder="Describe the circumstances of your detention or confinement. Include details about when, where, who was involved, what was said, and how long you were held..."
                    value={userScenario}
                    onChange={(e) => setUserScenario(e.target.value)}
                    rows={6}
                  />
                </div>
                
                <Button 
                  onClick={analyzeScenario} 
                  disabled={isAnalyzing}
                  className="w-full bg-amber-600 hover:bg-amber-700"
                >
                  {isAnalyzing ? (
                    <>
                      <Clock className="w-4 h-4 mr-2 animate-spin" />
                      Analyzing Case...
                    </>
                  ) : (
                    <>
                      <FileText className="w-4 h-4 mr-2" />
                      Analyze My Case
                    </>
                  )}
                </Button>

                {analysis && (
                  <Card className="border border-green-200 bg-green-50">
                    <CardHeader>
                      <CardTitle className="text-green-900">Legal Analysis Results</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="prose prose-sm max-w-none">
                        <ReactMarkdown>{analysis}</ReactMarkdown>
                      </div>
                    </CardContent>
                  </Card>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Resources Tab */}
          <TabsContent value="resources" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card className="border-0 shadow-lg bg-white">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <BookOpen className="w-5 h-5 text-blue-600" />
                    Key Legal Precedents
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4 text-sm">
                  <div>
                    <h4 className="font-semibold">Terry v. Ohio (1968)</h4>
                    <p className="text-slate-600">Established limits on investigative stops - must be brief and based on reasonable suspicion.</p>
                  </div>
                  <div>
                    <h4 className="font-semibold">Rodriguez v. United States (2015)</h4>
                    <p className="text-slate-600">Traffic stops cannot be extended beyond their original purpose without reasonable suspicion.</p>
                  </div>
                  <div>
                    <h4 className="font-semibold">Whren v. United States (1996)</h4>
                    <p className="text-slate-600">Clarified when traffic stops become unlawful detention.</p>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-0 shadow-lg bg-white">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Info className="w-5 h-5 text-purple-600" />
                    Know Your Rights
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4 text-sm">
                  <div>
                    <h4 className="font-semibold">Right to Leave</h4>
                    <p className="text-slate-600">You have the right to ask "Am I free to go?" and leave if not under arrest.</p>
                  </div>
                  <div>
                    <h4 className="font-semibold">Right to Remain Silent</h4>
                    <p className="text-slate-600">You don't have to answer questions beyond basic identification in many states.</p>
                  </div>
                  <div>
                    <h4 className="font-semibold">Right to Legal Counsel</h4>
                    <p className="text-slate-600">If arrested, you have the right to an attorney before questioning.</p>
                  </div>
                </CardContent>
              </Card>
            </div>

            <Alert className="bg-amber-50 border-amber-200">
              <Info className="h-4 w-4 text-amber-600" />
              <AlertDescription className="text-amber-800">
                <strong>Important:</strong> This guide provides general legal information and should not be considered legal advice. 
                Each case is unique and may require consultation with a qualified attorney familiar with your jurisdiction's laws.
              </AlertDescription>
            </Alert>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
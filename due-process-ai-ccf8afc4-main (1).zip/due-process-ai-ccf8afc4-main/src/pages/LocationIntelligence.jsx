import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { InvokeLLM } from "@/api/integrations";
import { MapPin, Search, Loader2, AlertTriangle, Users, Building, Newspaper } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts';

const locationSchema = {
    type: "object",
    properties: {
        location_summary: {
            type: "string",
            description: "A high-level summary of the location, including its general character and key features."
        },
        crime_statistics: {
            type: "object",
            properties: {
                overall_risk: { type: "string", enum: ["Low", "Moderate", "High", "Very High"] },
                crime_rate_comparison: { type: "string", description: "Comparison to national and state averages." },
                recent_trends: { type: "string", description: "Trends in crime over the last 12 months." },
                crime_types: {
                    type: "array",
                    items: {
                        type: "object",
                        properties: {
                            type: { type: "string" },
                            count: { type: "integer" },
                            trend: { type: "string", enum: ["increasing", "decreasing", "stable"] }
                        }
                    }
                }
            }
        },
        demographics: {
            type: "object",
            properties: {
                population: { type: "integer" },
                median_household_income: { type: "string" },
                poverty_rate: { type: "string" },
                ethnic_composition: {
                    type: "array",
                    items: {
                        type: "object",
                        properties: {
                            group: { type: "string" },
                            percentage: { type: "number" }
                        }
                    }
                }
            }
        },
        local_agencies: {
            type: "array",
            items: {
                type: "object",
                properties: {
                    name: { type: "string" },
                    type: { type: "string" },
                    address: { type: "string" },
                    phone: { type: "string" }
                }
            },
            description: "List of police departments, sheriff's offices, and courthouses in the area."
        },
        recent_news_incidents: {
            type: "array",
            items: {
                type: "object",
                properties: {
                    headline: { type: "string" },
                    source: { type: "string" },
                    date: { type: "string" },
                    summary: { type: "string" }
                }
            }
        },
        risk_analysis: {
            type: "string",
            description: "A detailed analysis of potential risks for legal proceedings or investigations in this area, considering crime rates, demographics, and local news."
        }
    },
    required: ["location_summary", "crime_statistics", "demographics", "risk_analysis"]
};

export default function LocationIntelligence() {
    const [locationQuery, setLocationQuery] = useState("");
    const [results, setResults] = useState(null);
    const [isSearching, setIsSearching] = useState(false);
    const { toast } = useToast();

    const handleSearch = async () => {
        if (!locationQuery.trim()) {
            toast({ title: "Location Required", description: "Please enter an address or area.", variant: "destructive" });
            return;
        }
        setIsSearching(true);
        setResults(null);
        try {
            const prompt = `Provide a detailed Location Intelligence report for: "${locationQuery}".
            
            Analyze the following aspects in detail:
            1.  **Crime Statistics:** Find the latest available crime data. Compare it to state and national averages. Detail the types of crimes and recent trends. Provide a clear risk assessment.
            2.  **Demographics:** Gather key demographic data including population, median income, poverty rate, and ethnic composition.
            3.  **Local Agencies:** Identify key local government and law enforcement agencies (police, sheriff, courts).
            4.  **Recent News:** Find recent news articles related to crime, law enforcement, or significant incidents in the area.
            5.  **Risk Analysis:** Synthesize all the above information into a strategic risk analysis relevant for legal or investigative purposes.`;

            const result = await InvokeLLM({
                prompt: prompt,
                add_context_from_internet: true,
                response_json_schema: locationSchema
            });

            setResults(result);
            toast({ title: "Analysis Complete", description: `Intelligence report for ${locationQuery} is ready.` });
        } catch (error) {
            console.error("Search error:", error);
            toast({ title: "Analysis Failed", description: "Unable to generate report. Please try again.", variant: "destructive" });
        } finally {
            setIsSearching(false);
        }
    };

    return (
        <div className="p-6 space-y-8">
            <div className="max-w-6xl mx-auto">
                <div className="mb-8">
                    <div className="flex items-center gap-3 mb-4">
                        <div className="w-12 h-12 bg-gradient-to-br from-teal-600 to-teal-700 rounded-xl flex items-center justify-center">
                            <MapPin className="w-7 h-7 text-white" />
                        </div>
                        <div>
                            <h1 className="text-3xl font-bold text-slate-900">Location Intelligence</h1>
                            <p className="text-slate-600 mt-1">Get a comprehensive intelligence report for any address or area.</p>
                        </div>
                    </div>
                </div>

                <Card className="border-0 shadow-lg bg-white mb-6">
                    <CardHeader>
                        <CardTitle>Analyze a Location</CardTitle>
                    </CardHeader>
                    <CardContent className="flex gap-4">
                        <Input 
                            placeholder="Enter a full address, city, or zip code" 
                            value={locationQuery}
                            onChange={(e) => setLocationQuery(e.target.value)}
                        />
                        <Button 
                            onClick={handleSearch} 
                            disabled={isSearching}
                            className="bg-teal-600 hover:bg-teal-700 gap-2 whitespace-nowrap"
                        >
                            {isSearching ? <><Loader2 className="w-4 h-4 animate-spin" /> Analyzing...</> : <><Search className="w-4 h-4" /> Analyze</>}
                        </Button>
                    </CardContent>
                </Card>

                {results && (
                    <div className="space-y-6">
                        <Card className="border-0 shadow-lg bg-white">
                            <CardHeader>
                                <CardTitle>Overall Assessment for "{locationQuery}"</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <p className="text-slate-700 mb-4">{results.location_summary}</p>
                                <Card className="bg-slate-50 p-4">
                                    <CardHeader className="p-0 pb-2">
                                        <CardTitle className="text-lg flex items-center gap-2"><AlertTriangle className="w-5 h-5 text-red-600"/>Strategic Risk Analysis</CardTitle>
                                    </CardHeader>
                                    <CardContent className="p-0">
                                        <p className="text-slate-800">{results.risk_analysis}</p>
                                    </CardContent>
                                </Card>
                            </CardContent>
                        </Card>

                        {results.crime_statistics && (
                            <Card className="border-0 shadow-lg bg-white">
                                <CardHeader>
                                    <CardTitle className="flex items-center gap-2"><AlertTriangle className="w-5 h-5"/>Crime Statistics</CardTitle>
                                </CardHeader>
                                <CardContent>
                                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-6 text-center">
                                        <div className="bg-red-50 p-4 rounded-lg"><p className="text-sm text-red-700">Overall Risk</p><p className="text-2xl font-bold text-red-900">{results.crime_statistics.overall_risk}</p></div>
                                        <div className="bg-yellow-50 p-4 rounded-lg"><p className="text-sm text-yellow-700">Rate vs. Average</p><p className="text-lg font-semibold text-yellow-900">{results.crime_statistics.crime_rate_comparison}</p></div>
                                        <div className="bg-blue-50 p-4 rounded-lg"><p className="text-sm text-blue-700">Recent Trends</p><p className="text-lg font-semibold text-blue-900">{results.crime_statistics.recent_trends}</p></div>
                                    </div>
                                    <h4 className="font-semibold text-slate-800 mb-2">Crime Type Breakdown (Last 12 Months)</h4>
                                     <div className="h-72">
                                        <ResponsiveContainer width="100%" height="100%">
                                            <BarChart data={results.crime_statistics.crime_types} margin={{ top: 5, right: 20, left: -10, bottom: 5 }}>
                                                <CartesianGrid strokeDasharray="3 3" />
                                                <XAxis dataKey="type" />
                                                <YAxis />
                                                <Tooltip />
                                                <Bar dataKey="count" fill="#334155" />
                                            </BarChart>
                                        </ResponsiveContainer>
                                    </div>
                                </CardContent>
                            </Card>
                        )}
                        
                        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                           {results.demographics && (
                                <Card className="border-0 shadow-lg bg-white">
                                    <CardHeader>
                                        <CardTitle className="flex items-center gap-2"><Users className="w-5 h-5"/>Demographics</CardTitle>
                                    </CardHeader>
                                    <CardContent className="space-y-3">
                                       <p><strong>Population:</strong> {results.demographics.population?.toLocaleString()}</p>
                                       <p><strong>Median Household Income:</strong> {results.demographics.median_household_income}</p>
                                       <p><strong>Poverty Rate:</strong> {results.demographics.poverty_rate}</p>
                                       <h4 className="font-semibold pt-2">Ethnic Composition</h4>
                                       <div className="space-y-1">
                                            {results.demographics.ethnic_composition?.map(e => (
                                                <div key={e.group} className="flex justify-between text-sm">
                                                    <span>{e.group}</span>
                                                    <span>{e.percentage}%</span>
                                                </div>
                                            ))}
                                       </div>
                                    </CardContent>
                                </Card>
                            )}

                           {results.local_agencies && (
                                <Card className="border-0 shadow-lg bg-white">
                                    <CardHeader>
                                        <CardTitle className="flex items-center gap-2"><Building className="w-5 h-5"/>Local Agencies</CardTitle>
                                    </CardHeader>
                                    <CardContent className="space-y-4">
                                        {results.local_agencies.map((agency, i) => (
                                            <div key={i} className="p-3 bg-slate-50 rounded-lg">
                                                <h4 className="font-semibold">{agency.name}</h4>
                                                <p className="text-sm text-slate-600">{agency.type}</p>
                                                <p className="text-sm text-slate-600">{agency.address}</p>
                                                <p className="text-sm text-slate-600">{agency.phone}</p>
                                            </div>
                                        ))}
                                    </CardContent>
                                </Card>
                            )}
                        </div>
                        
                        {results.recent_news_incidents?.length > 0 && (
                            <Card className="border-0 shadow-lg bg-white">
                                <CardHeader>
                                    <CardTitle className="flex items-center gap-2"><Newspaper className="w-5 h-5"/>Recent News & Incidents</CardTitle>
                                </CardHeader>
                                <CardContent className="space-y-4">
                                    {results.recent_news_incidents.map((news, index) => (
                                        <div key={index} className="p-4 bg-slate-50 rounded-lg">
                                            <h4 className="font-semibold text-slate-900">{news.headline}</h4>
                                            <div className="text-xs text-slate-600 mt-1">{news.source} • {news.date}</div>
                                            <p className="text-sm text-slate-700 mt-2">{news.summary}</p>
                                        </div>
                                    ))}
                                </CardContent>
                            </Card>
                        )}
                    </div>
                )}
            </div>
        </div>
    );
}
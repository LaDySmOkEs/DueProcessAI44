import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Users } from "lucide-react";

export default function CommunityAlerts() {
    return (
        <div className="p-6 space-y-8">
            <div className="max-w-4xl mx-auto">
                <div className="mb-8">
                    <div className="flex items-center gap-3 mb-4">
                        <div className="w-12 h-12 bg-gradient-to-br from-orange-500 to-orange-600 rounded-xl flex items-center justify-center">
                            <Users className="w-7 h-7 text-white" />
                        </div>
                        <div>
                            <h1 className="text-3xl font-bold text-slate-900">Community Network</h1>
                            <p className="text-slate-600 mt-1">Connect with others and stay informed.</p>
                        </div>
                    </div>
                </div>

                <Card className="border-0 shadow-lg bg-white">
                    <CardHeader>
                        <CardTitle>Community Alerts & Network</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <p className="text-slate-700">This feature is under construction. The goal is to create a secure space for users to share information, post alerts about government activity in their area, and connect with others who have had similar experiences. This network will be vital for building collective power and awareness.</p>
                        <Button className="mt-4" disabled>View Alerts</Button>
                    </CardContent>
                </Card>
            </div>
        </div>
    );
}

import React, { useState, useEffect } from 'react';
import { useSearchParams, useNavigate, Link } from 'react-router-dom'; // Added Link
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { LegalCase, LegalDocument } from "@/api/entities";
import { createPageUrl } from "@/utils";
import { ArrowLeft, Calendar, Users, FileText, Edit, Briefcase, BrainCircuit } from "lucide-react"; // Added BrainCircuit
import { format } from "date-fns";

export default function CaseDetails() {
    const [searchParams] = useSearchParams();
    const navigate = useNavigate();
    const caseId = searchParams.get('id');
    
    const [caseData, setCaseData] = useState(null);
    const [documents, setDocuments] = useState([]);
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        if (caseId) {
            loadCaseDetails();
        }
    }, [caseId]);

    const loadCaseDetails = async () => {
        try {
            // Load case details
            const cases = await LegalCase.list();
            const foundCase = cases.find(c => c.id === caseId);
            setCaseData(foundCase);

            // Load related documents
            const allDocuments = await LegalDocument.list();
            const relatedDocs = allDocuments.filter(doc => doc.case_id === caseId);
            setDocuments(relatedDocs);
        } catch (error) {
            console.error("Error loading case details:", error);
        } finally {
            setIsLoading(false);
        }
    };

    const getStatusColor = (status) => {
        switch (status) {
            case 'active': return 'bg-green-100 text-green-800 border-green-200';
            case 'pending': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
            case 'closed': return 'bg-slate-100 text-slate-800 border-slate-200';
            case 'archived': return 'bg-purple-100 text-purple-800 border-purple-200';
            default: return 'bg-slate-100 text-slate-800 border-slate-200';
        }
    };

    if (isLoading) {
        return (
            <div className="p-6 space-y-8">
                <div className="max-w-7xl mx-auto">
                    <div className="animate-pulse space-y-6">
                        <div className="h-8 bg-slate-200 rounded w-1/3"></div>
                        <div className="h-4 bg-slate-200 rounded w-1/2"></div>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                            <div className="h-32 bg-slate-200 rounded"></div>
                            <div className="h-32 bg-slate-200 rounded"></div>
                            <div className="h-32 bg-slate-200 rounded"></div>
                        </div>
                    </div>
                </div>
            </div>
        );
    }

    if (!caseData) {
        return (
            <div className="p-6 space-y-8">
                <div className="max-w-7xl mx-auto text-center">
                    <h1 className="text-2xl font-bold text-slate-900 mb-4">Case Not Found</h1>
                    <p className="text-slate-600 mb-6">The requested case could not be found.</p>
                    <Button onClick={() => navigate(createPageUrl("CaseManager"))}>
                        <ArrowLeft className="w-4 h-4 mr-2" />
                        Back to Case Manager
                    </Button>
                </div>
            </div>
        );
    }

    return (
        <div className="p-6 space-y-8">
            <div className="max-w-7xl mx-auto">
                {/* Header */}
                <div className="mb-8">
                    <div className="flex items-center justify-between mb-4">
                        <div className="flex items-center gap-3">
                            <Button 
                                variant="outline" 
                                onClick={() => navigate(createPageUrl("CaseManager"))}
                                className="gap-2"
                            >
                                <ArrowLeft className="w-4 h-4" />
                                Back
                            </Button>
                            <div className="w-12 h-12 bg-gradient-to-br from-slate-600 to-slate-700 rounded-xl flex items-center justify-center">
                                <Briefcase className="w-7 h-7 text-white" />
                            </div>
                            <div>
                                <h1 className="text-3xl font-bold text-slate-900">{caseData?.case_name}</h1>
                                <p className="text-slate-600 capitalize">{caseData?.case_type.replace(/_/g, ' ')}</p>
                            </div>
                        </div>
                        <div className="flex items-center gap-3">
                            <Badge className={`${getStatusColor(caseData?.status)} border`}>
                                {caseData?.status}
                            </Badge>
                            <Link to={createPageUrl("LegalDraftsman")}>
                                <Button className="bg-purple-600 hover:bg-purple-700 gap-2">
                                    <BrainCircuit className="w-4 h-4" />
                                    Get AI Document Suggestions
                                </Button>
                            </Link>
                            <Button variant="outline" className="gap-2">
                                <Edit className="w-4 h-4" />
                                Edit Case
                            </Button>
                        </div>
                    </div>
                </div>

                {/* Case Overview */}
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-8">
                    <Card className="border-0 shadow-lg bg-white">
                        <CardHeader>
                            <CardTitle className="text-lg">Case Information</CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-4">
                            {caseData.case_number && (
                                <div>
                                    <label className="text-sm font-medium text-slate-600">Case Number</label>
                                    <p className="text-slate-900">{caseData.case_number}</p>
                                </div>
                            )}
                            <div>
                                <label className="text-sm font-medium text-slate-600">Created</label>
                                <p className="text-slate-900">{format(new Date(caseData.created_date), 'MMM d, yyyy')}</p>
                            </div>
                            {caseData.next_deadline && (
                                <div className="flex items-center gap-2 p-3 bg-amber-50 border border-amber-200 rounded-lg">
                                    <Calendar className="w-5 h-5 text-amber-600" />
                                    <div>
                                        <label className="text-sm font-medium text-amber-900">Next Deadline</label>
                                        <p className="text-amber-800">{format(new Date(caseData.next_deadline), 'MMM d, yyyy')}</p>
                                    </div>
                                </div>
                            )}
                        </CardContent>
                    </Card>

                    <Card className="border-0 shadow-lg bg-white">
                        <CardHeader>
                            <CardTitle className="text-lg flex items-center gap-2">
                                <Users className="w-5 h-5" />
                                Key Parties
                            </CardTitle>
                        </CardHeader>
                        <CardContent>
                            {caseData.key_parties && caseData.key_parties.length > 0 ? (
                                <div className="flex flex-wrap gap-2">
                                    {caseData.key_parties.map((party, index) => (
                                        <Badge key={index} variant="outline" className="bg-slate-50">
                                            {party}
                                        </Badge>
                                    ))}
                                </div>
                            ) : (
                                <p className="text-slate-500 text-sm">No parties specified</p>
                            )}
                        </CardContent>
                    </Card>

                    <Card className="border-0 shadow-lg bg-white">
                        <CardHeader>
                            <CardTitle className="text-lg flex items-center gap-2">
                                <FileText className="w-5 h-5" />
                                Documents
                            </CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="text-center">
                                <p className="text-2xl font-bold text-slate-900">{documents.length}</p>
                                <p className="text-sm text-slate-600">Documents</p>
                            </div>
                        </CardContent>
                    </Card>
                </div>

                {/* Case Description */}
                {caseData.description && (
                    <Card className="border-0 shadow-lg bg-white mb-8">
                        <CardHeader>
                            <CardTitle>Case Description</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <p className="text-slate-700 leading-relaxed">{caseData.description}</p>
                        </CardContent>
                    </Card>
                )}

                {/* Related Documents */}
                <Card className="border-0 shadow-lg bg-white">
                    <CardHeader>
                        <CardTitle>Related Documents</CardTitle>
                    </CardHeader>
                    <CardContent>
                        {documents.length === 0 ? (
                            <div className="text-center py-8">
                                <FileText className="w-12 h-12 text-slate-400 mx-auto mb-4" />
                                <h3 className="text-lg font-semibold text-slate-900 mb-2">No Documents Yet</h3>
                                <p className="text-slate-600 mb-4">Upload documents to start building your case file</p>
                                <Button className="bg-amber-600 hover:bg-amber-700">
                                    Upload Document
                                </Button>
                            </div>
                        ) : (
                            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                                {documents.map((doc) => (
                                    <div key={doc.id} className="p-4 border border-slate-200 rounded-lg hover:shadow-md transition-shadow">
                                        <h4 className="font-semibold text-slate-900 mb-2">{doc.document_name}</h4>
                                        <Badge variant="outline" className="mb-2 capitalize">
                                            {doc.document_type.replace(/_/g, ' ')}
                                        </Badge>
                                        {doc.ai_summary && (
                                            <p className="text-sm text-slate-600 line-clamp-2 mb-3">{doc.ai_summary}</p>
                                        )}
                                        <Button variant="outline" size="sm" asChild>
                                            <a href={doc.file_url} target="_blank" rel="noopener noreferrer">
                                                View Document
                                            </a>
                                        </Button>
                                    </div>
                                ))}
                            </div>
                        )}
                    </CardContent>
                </Card>
            </div>
        </div>
    );
}

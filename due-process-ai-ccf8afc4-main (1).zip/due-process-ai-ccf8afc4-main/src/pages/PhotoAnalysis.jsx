
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input"; // Added import for Input component
import { InvokeLLM, UploadFile } from "@/api/integrations";
import { Camera, Search, Loader2, FileUp, Eye, TextCursor, AlertCircle } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";

const photoSchema = {
    type: "object",
    properties: {
        overall_summary: {
            type: "string",
            description: "A detailed, narrative summary of everything visible in the photo."
        },
        objects_identified: {
            type: "array",
            items: {
                type: "object",
                properties: {
                    object: { type: "string" },
                    description: { type: "string" },
                    potential_relevance: { type: "string" }
                }
            }
        },
        people_identified: {
            type: "array",
            items: {
                type: "object",
                properties: {
                    description: { type: "string" },
                    actions: { type: "string" }
                }
            }
        },
        text_in_image: {
            type: "array",
            items: {
                type: "string"
            },
            description: "Any text that is clearly legible in the image."
        },
        potential_evidence_points: {
            type: "array",
            items: {
                type: "string"
            },
            description: "A bulleted list of specific details that could serve as evidence."
        },
        inconsistencies_or_anomalies: {
            type: "array",
            items: {
                type: "string"
            },
            description: "A list of any unusual, inconsistent, or potentially manipulated aspects of the photo."
        },
        inferred_context: {
            type: "object",
            properties: {
                time_of_day: { type: "string" },
                lighting: { type: "string" },
                potential_location_type: { type: "string" }
            }
        }
    },
    required: ["overall_summary"]
};

export default function PhotoAnalysis() {
    const [file, setFile] = useState(null);
    const [preview, setPreview] = useState(null);
    const [results, setResults] = useState(null);
    const [isAnalyzing, setIsAnalyzing] = useState(false);
    const { toast } = useToast();

    const handleFileChange = (e) => {
        const selectedFile = e.target.files[0];
        if (selectedFile) {
            setFile(selectedFile);
            setPreview(URL.createObjectURL(selectedFile));
            setResults(null);
        }
    };

    const handleAnalyze = async () => {
        if (!file) {
            toast({ title: "No File Selected", description: "Please upload a photo to analyze.", variant: "destructive" });
            return;
        }
        setIsAnalyzing(true);
        setResults(null);
        try {
            const { file_url } = await UploadFile({ file });

            const prompt = `Perform a forensic analysis of the provided image. Be extremely detailed and objective.
            
            1.  **Overall Summary:** Describe the scene, people, objects, and environment in a comprehensive narrative.
            2.  **Objects:** Identify every significant object. Note its condition and potential relevance.
            3.  **People:** Describe each person's appearance, posture, and actions.
            4.  **Text:** Transcribe any legible text from signs, papers, or clothing.
            5.  **Evidence Points:** Extract specific, factual details that could be legally significant (e.g., "subject is holding a blue crowbar in their right hand," "the clock on the wall reads 3:15 PM").
            6.  **Anomalies:** Point out anything unusual, such as strange shadows, reflections, or objects that seem out of place.
            7.  **Context:** Infer the time of day, lighting conditions, and type of location (e.g., residential kitchen, commercial warehouse).`;

            const result = await InvokeLLM({
                prompt: prompt,
                file_urls: [file_url],
                response_json_schema: photoSchema
            });

            setResults(result);
            toast({ title: "Analysis Complete", description: "Photo analysis is complete." });

        } catch (error) {
            console.error("Analysis error:", error);
            toast({ title: "Analysis Failed", description: "Could not analyze the photo.", variant: "destructive" });
        } finally {
            setIsAnalyzing(false);
        }
    };

    return (
        <div className="p-6 space-y-8">
            <div className="max-w-6xl mx-auto">
                <div className="mb-8">
                    <div className="flex items-center gap-3 mb-4">
                        <div className="w-12 h-12 bg-gradient-to-br from-pink-600 to-pink-700 rounded-xl flex items-center justify-center">
                            <Camera className="w-7 h-7 text-white" />
                        </div>
                        <div>
                            <h1 className="text-3xl font-bold text-slate-900">AI Photo & Evidence Analysis</h1>
                            <p className="text-slate-600 mt-1">Extract critical details, text, and potential evidence from images.</p>
                        </div>
                    </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div className="space-y-6">
                        <Card className="border-0 shadow-lg bg-white">
                            <CardHeader>
                                <CardTitle>Upload Photo</CardTitle>
                            </CardHeader>
                            <CardContent className="space-y-4">
                                <div className="p-6 border-2 border-dashed border-slate-300 rounded-lg text-center">
                                    <FileUp className="mx-auto w-12 h-12 text-slate-400 mb-4" />
                                    <Input id="picture" type="file" accept="image/*" onChange={handleFileChange} className="hidden" />
                                    <label htmlFor="picture" className="cursor-pointer bg-slate-100 text-slate-800 px-4 py-2 rounded-md hover:bg-slate-200">
                                        Choose a file
                                    </label>
                                    {file && <p className="text-sm text-slate-500 mt-2">{file.name}</p>}
                                </div>
                                {preview && (
                                    <div>
                                        <img src={preview} alt="Preview" className="max-h-64 w-full object-contain rounded-lg" />
                                    </div>
                                )}
                                <Button onClick={handleAnalyze} disabled={!file || isAnalyzing} className="w-full bg-pink-600 hover:bg-pink-700 gap-2">
                                    {isAnalyzing ? <><Loader2 className="w-4 h-4 animate-spin" /> Analyzing...</> : <><Search className="w-4 h-4" /> Analyze Photo</>}
                                </Button>
                            </CardContent>
                        </Card>
                    </div>

                    <div className="space-y-6">
                        {isAnalyzing && (
                            <Card className="border-0 shadow-lg bg-white">
                                <CardContent className="p-12 text-center">
                                    <Loader2 className="w-12 h-12 text-pink-600 animate-spin mx-auto mb-4" />
                                    <h3 className="text-lg font-semibold text-slate-900">Performing Forensic Analysis...</h3>
                                </CardContent>
                            </Card>
                        )}
                        {results && (
                            <>
                                <Card className="border-0 shadow-lg bg-white">
                                    <CardHeader>
                                        <CardTitle className="flex items-center gap-2"><Eye className="w-5 h-5"/>Analysis Summary</CardTitle>
                                    </CardHeader>
                                    <CardContent>
                                        <p className="text-slate-700">{results.overall_summary}</p>
                                    </CardContent>
                                </Card>
                                 {results.potential_evidence_points?.length > 0 && (
                                    <Card className="border-0 shadow-lg bg-white">
                                        <CardHeader>
                                            <CardTitle className="flex items-center gap-2"><Search className="w-5 h-5 text-green-600"/>Potential Evidence</CardTitle>
                                        </CardHeader>
                                        <CardContent>
                                            <ul className="list-disc list-inside space-y-2 text-sm text-slate-800">
                                                {results.potential_evidence_points.map((point, i) => <li key={i}>{point}</li>)}
                                            </ul>
                                        </CardContent>
                                    </Card>
                                )}
                                {results.inconsistencies_or_anomalies?.length > 0 && (
                                     <Card className="border-0 shadow-lg bg-white">
                                        <CardHeader>
                                            <CardTitle className="flex items-center gap-2"><AlertCircle className="w-5 h-5 text-red-600"/>Anomalies Detected</CardTitle>
                                        </CardHeader>
                                        <CardContent>
                                            <ul className="list-disc list-inside space-y-2 text-sm text-red-800">
                                                {results.inconsistencies_or_anomalies.map((point, i) => <li key={i}>{point}</li>)}
                                            </ul>
                                        </CardContent>
                                    </Card>
                                )}
                                {results.text_in_image?.length > 0 && (
                                     <Card className="border-0 shadow-lg bg-white">
                                        <CardHeader>
                                            <CardTitle className="flex items-center gap-2"><TextCursor className="w-5 h-5 text-blue-600"/>Text Found in Image</CardTitle>
                                        </CardHeader>
                                        <CardContent>
                                            <div className="bg-slate-900 text-white font-mono p-4 rounded-lg">
                                                {results.text_in_image.join('\n')}
                                            </div>
                                        </CardContent>
                                    </Card>
                                )}
                            </>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
}

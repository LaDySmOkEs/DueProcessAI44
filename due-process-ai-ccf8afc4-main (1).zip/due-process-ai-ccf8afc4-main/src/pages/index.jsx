import Layout from "./Layout.jsx";

import Dashboard from "./Dashboard";

import KnowYourRights from "./KnowYourRights";

import DocumentAnalyzer from "./DocumentAnalyzer";

import AntiDespotismDashboard from "./AntiDespotismDashboard";

import SelfLitigantCenter from "./SelfLitigantCenter";

import ClassActionRegistry from "./ClassActionRegistry";

import SubmitViolation from "./SubmitViolation";

import ClassActionInvestigation from "./ClassActionInvestigation";

import CaseManager from "./CaseManager";

import CreateCase from "./CreateCase";

import MyIncidents from "./MyIncidents";

import PoliceEncounters from "./PoliceEncounters";

import LegalResources from "./LegalResources";

import CaseDetails from "./CaseDetails";

import DigitalInvestigator from "./DigitalInvestigator";

import PublicRecordsRequest from "./PublicRecordsRequest";

import OfficerLookup from "./OfficerLookup";

import ConstitutionalViolations from "./ConstitutionalViolations";

import CommunityAlerts from "./CommunityAlerts";

import ReportIncident from "./ReportIncident";

import LegalDraftsman from "./LegalDraftsman";

import CourtroomSimulator from "./CourtroomSimulator";

import PublicRecordsSearch from "./PublicRecordsSearch";

import WitnessLocator from "./WitnessLocator";

import LocationIntelligence from "./LocationIntelligence";

import SocialMediaInvestigation from "./SocialMediaInvestigation";

import PhotoAnalysis from "./PhotoAnalysis";

import CivilRightsComplaintBuilder from "./CivilRightsComplaintBuilder";

import Billing from "./Billing";

import JudicialAccountability from "./JudicialAccountability";

import CourtAccessCenter from "./CourtAccessCenter";

import MaliciousProsecutionDefense from "./MaliciousProsecutionDefense";

import DocumentManager from "./DocumentManager";

import LegalDefenseMemorandum from "./LegalDefenseMemorandum";

import EvidencePreservation from "./EvidencePreservation";

import AntiCorruptionCenter from "./AntiCorruptionCenter";

import ComplaintTracker from "./ComplaintTracker";

import FalseImprisonmentGuide from "./FalseImprisonmentGuide";

import { BrowserRouter as Router, Route, Routes, useLocation } from 'react-router-dom';

const PAGES = {
    
    Dashboard: Dashboard,
    
    KnowYourRights: KnowYourRights,
    
    DocumentAnalyzer: DocumentAnalyzer,
    
    AntiDespotismDashboard: AntiDespotismDashboard,
    
    SelfLitigantCenter: SelfLitigantCenter,
    
    ClassActionRegistry: ClassActionRegistry,
    
    SubmitViolation: SubmitViolation,
    
    ClassActionInvestigation: ClassActionInvestigation,
    
    CaseManager: CaseManager,
    
    CreateCase: CreateCase,
    
    MyIncidents: MyIncidents,
    
    PoliceEncounters: PoliceEncounters,
    
    LegalResources: LegalResources,
    
    CaseDetails: CaseDetails,
    
    DigitalInvestigator: DigitalInvestigator,
    
    PublicRecordsRequest: PublicRecordsRequest,
    
    OfficerLookup: OfficerLookup,
    
    ConstitutionalViolations: ConstitutionalViolations,
    
    CommunityAlerts: CommunityAlerts,
    
    ReportIncident: ReportIncident,
    
    LegalDraftsman: LegalDraftsman,
    
    CourtroomSimulator: CourtroomSimulator,
    
    PublicRecordsSearch: PublicRecordsSearch,
    
    WitnessLocator: WitnessLocator,
    
    LocationIntelligence: LocationIntelligence,
    
    SocialMediaInvestigation: SocialMediaInvestigation,
    
    PhotoAnalysis: PhotoAnalysis,
    
    CivilRightsComplaintBuilder: CivilRightsComplaintBuilder,
    
    Billing: Billing,
    
    JudicialAccountability: JudicialAccountability,
    
    CourtAccessCenter: CourtAccessCenter,
    
    MaliciousProsecutionDefense: MaliciousProsecutionDefense,
    
    DocumentManager: DocumentManager,
    
    LegalDefenseMemorandum: LegalDefenseMemorandum,
    
    EvidencePreservation: EvidencePreservation,
    
    AntiCorruptionCenter: AntiCorruptionCenter,
    
    ComplaintTracker: ComplaintTracker,
    
    FalseImprisonmentGuide: FalseImprisonmentGuide,
    
}

function _getCurrentPage(url) {
    if (url.endsWith('/')) {
        url = url.slice(0, -1);
    }
    let urlLastPart = url.split('/').pop();
    if (urlLastPart.includes('?')) {
        urlLastPart = urlLastPart.split('?')[0];
    }

    const pageName = Object.keys(PAGES).find(page => page.toLowerCase() === urlLastPart.toLowerCase());
    return pageName || Object.keys(PAGES)[0];
}

// Create a wrapper component that uses useLocation inside the Router context
function PagesContent() {
    const location = useLocation();
    const currentPage = _getCurrentPage(location.pathname);
    
    return (
        <Layout currentPageName={currentPage}>
            <Routes>            
                
                    <Route path="/" element={<Dashboard />} />
                
                
                <Route path="/Dashboard" element={<Dashboard />} />
                
                <Route path="/KnowYourRights" element={<KnowYourRights />} />
                
                <Route path="/DocumentAnalyzer" element={<DocumentAnalyzer />} />
                
                <Route path="/AntiDespotismDashboard" element={<AntiDespotismDashboard />} />
                
                <Route path="/SelfLitigantCenter" element={<SelfLitigantCenter />} />
                
                <Route path="/ClassActionRegistry" element={<ClassActionRegistry />} />
                
                <Route path="/SubmitViolation" element={<SubmitViolation />} />
                
                <Route path="/ClassActionInvestigation" element={<ClassActionInvestigation />} />
                
                <Route path="/CaseManager" element={<CaseManager />} />
                
                <Route path="/CreateCase" element={<CreateCase />} />
                
                <Route path="/MyIncidents" element={<MyIncidents />} />
                
                <Route path="/PoliceEncounters" element={<PoliceEncounters />} />
                
                <Route path="/LegalResources" element={<LegalResources />} />
                
                <Route path="/CaseDetails" element={<CaseDetails />} />
                
                <Route path="/DigitalInvestigator" element={<DigitalInvestigator />} />
                
                <Route path="/PublicRecordsRequest" element={<PublicRecordsRequest />} />
                
                <Route path="/OfficerLookup" element={<OfficerLookup />} />
                
                <Route path="/ConstitutionalViolations" element={<ConstitutionalViolations />} />
                
                <Route path="/CommunityAlerts" element={<CommunityAlerts />} />
                
                <Route path="/ReportIncident" element={<ReportIncident />} />
                
                <Route path="/LegalDraftsman" element={<LegalDraftsman />} />
                
                <Route path="/CourtroomSimulator" element={<CourtroomSimulator />} />
                
                <Route path="/PublicRecordsSearch" element={<PublicRecordsSearch />} />
                
                <Route path="/WitnessLocator" element={<WitnessLocator />} />
                
                <Route path="/LocationIntelligence" element={<LocationIntelligence />} />
                
                <Route path="/SocialMediaInvestigation" element={<SocialMediaInvestigation />} />
                
                <Route path="/PhotoAnalysis" element={<PhotoAnalysis />} />
                
                <Route path="/CivilRightsComplaintBuilder" element={<CivilRightsComplaintBuilder />} />
                
                <Route path="/Billing" element={<Billing />} />
                
                <Route path="/JudicialAccountability" element={<JudicialAccountability />} />
                
                <Route path="/CourtAccessCenter" element={<CourtAccessCenter />} />
                
                <Route path="/MaliciousProsecutionDefense" element={<MaliciousProsecutionDefense />} />
                
                <Route path="/DocumentManager" element={<DocumentManager />} />
                
                <Route path="/LegalDefenseMemorandum" element={<LegalDefenseMemorandum />} />
                
                <Route path="/EvidencePreservation" element={<EvidencePreservation />} />
                
                <Route path="/AntiCorruptionCenter" element={<AntiCorruptionCenter />} />
                
                <Route path="/ComplaintTracker" element={<ComplaintTracker />} />
                
                <Route path="/FalseImprisonmentGuide" element={<FalseImprisonmentGuide />} />
                
            </Routes>
        </Layout>
    );
}

export default function Pages() {
    return (
        <Router>
            <PagesContent />
        </Router>
    );
}
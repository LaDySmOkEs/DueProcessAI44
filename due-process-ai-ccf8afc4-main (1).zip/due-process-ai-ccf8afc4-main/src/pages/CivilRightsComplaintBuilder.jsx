
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Shield, Scale, FileText, Download, AlertTriangle } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";
import { Textarea } from "@/components/ui/textarea"; // Added import for Textarea

// Mock InvokeLLM function for demonstration purposes.
// In a real application, this would be an actual API call to an LLM service.
const InvokeLLM = async ({ prompt }) => {
    return new Promise(resolve => {
        setTimeout(() => {
            const mockComplaint = `UNITED STATES DISTRICT COURT
FOR THE FEDERAL DISTRICT OF FREEDOM STATE

[Plaintiff Name],
Plaintiff,

v.

[Defendant Name/Entity],
Defendant(s).

Case No.: [Case Number]

JURY DEMAND

Plaintiff [Plaintiff Name], by and through [his/her/their] undersigned counsel, brings this action for damages and injunctive relief against the Defendants for violations of [his/her/their] rights under the United States Constitution based on the following facts:

JURISDICTION AND VENUE
1. This Court has subject matter jurisdiction over this action pursuant to 28 U.S.C. §§ 1331 and 1343(a)(3), as this action arises under the Constitution of the United States and 42 U.S.C. § 1983.
2. Venue is proper in this district under 28 U.S.C. § 1391(b) as the events giving rise to the claim occurred within this judicial district.

STATEMENT OF FACTS
${prompt.split('---')[1].trim()}
(Additional legal boilerplate and claims would be generated here based on detailed analysis of facts)

PRAYER FOR RELIEF
WHEREFORE, Plaintiff respectfully requests that this Court enter judgment in her favor and against Defendants, and award:
A. Compensatory damages in an amount to be determined at trial;
B. Punitive damages against individual defendants in an amount to be determined at trial;
C. Injunctive relief as appropriate;
D. Reasonable attorneys' fees and costs pursuant to 42 U.S.C. § 1988; and
E. Such other and further relief as the Court deems just and proper.

Dated: [Current Date]

Respectfully submitted,
[Your Name/Counsel Name]
[Address]
[Contact Information]
`;
            resolve(mockComplaint);
        }, 2000); // Simulate network delay
    });
};


const demoComplaint = {
    complete_complaint: `UNITED STATES DISTRICT COURT
FOR THE FEDERAL DISTRICT OF FREEDOM STATE

JANE DOE,
Plaintiff,

v.

OFFICER JOHN SMITH, in his individual capacity,
and THE CITY OF LIBERTY, a municipal corporation,
Defendants.

Case No.: [Case Number]

JURY DEMAND

Plaintiff Jane Doe, by and through her undersigned counsel, brings this action for damages and injunctive relief against the Defendants for violations of her rights under the United States Constitution and demands a trial by jury on all issues so triable.

JURISDICTION AND VENUE
1. This Court has subject matter jurisdiction over this action pursuant to 28 U.S.C. §§ 1331 and 1343(a)(3), as this action arises under the Constitution of the United States and 42 U.S.C. § 1983.
2. Venue is proper in this district under 28 U.S.C. § 1391(b) as the events giving rise to the claim occurred within this judicial district.

PARTIES
3. Plaintiff JANE DOE is a citizen of the United States and a resident of Liberty City, Freedom State.
4. Defendant OFFICER JOHN SMITH was, at all times relevant to this complaint, a sworn police officer employed by the Liberty City Police Department, acting under color of state law.
5. Defendant CITY OF LIBERTY is a municipal corporation organized under the laws of Freedom State and is responsible for the operation of the Liberty City Police Department.

STATEMENT OF FACTS
6. On or about May 1, 2024, Plaintiff Jane Doe was peacefully assembling on a public sidewalk at the corner of Constitution Ave & Freedom St in Liberty City.
7. Defendant Officer John Smith, without probable cause or reasonable suspicion, approached Plaintiff and demanded she cease her lawful activity.
8. When Plaintiff asserted her First Amendment right to peacefully assemble, Defendant Officer Smith unlawfully seized and arrested her.
9. Plaintiff was handcuffed with excessive force, causing bruising and injury to her wrists.
10. Plaintiff was detained for approximately 12 hours and was subsequently released without any charges being filed against her.
11. The actions of Defendant Officer Smith were taken pursuant to a policy, custom, or practice of the City of Liberty that encourages or is deliberately indifferent to such unconstitutional conduct by its officers.

COUNT I - 42 U.S.C. § 1983 - VIOLATION OF FIRST AND FOURTH AMENDMENT RIGHTS
(Against Defendant Officer John Smith)
12. Plaintiff realleges and incorporates the preceding paragraphs.
13. Defendant Officer Smith’s arrest of Plaintiff without probable cause constituted an unreasonable seizure in violation of the Fourth Amendment.
14. Defendant Officer Smith’s actions in arresting Plaintiff for engaging in protected speech and assembly violated her rights under the First Amendment.
15. As a direct and proximate result of Defendant’s actions, Plaintiff suffered physical injury, emotional distress, and financial damages.

COUNT II - 42 U.S.C. § 1983 - MONELL CLAIM
(Against Defendant City of Liberty)
16. Plaintiff realleges and incorporates the preceding paragraphs.
17. The City of Liberty failed to adequately train and supervise its police officers, including Defendant Officer Smith, regarding citizens' First and Fourth Amendment rights, demonstrating deliberate indifference to the constitutional rights of persons in Liberty City.
18. This failure to train was the moving force behind the constitutional violations suffered by Plaintiff.

PRAYER FOR RELIEF
WHEREFORE, Plaintiff respectfully requests that this Court enter judgment in her favor and against Defendants, and award:
A. Compensatory damages in an amount to be determined at trial;
B. Punitive damages against Defendant Officer John Smith in an amount to be determined at trial;
C. Injunctive relief ordering the City of Liberty to implement new training and policies regarding protected First Amendment activities;
D. Reasonable attorneys' fees and costs pursuant to 42 U.S.C. § 1988; and
E. Such other and further relief as the Court deems just and proper.

Dated: [Date]

Respectfully submitted,
/s/ Jane Doe
Jane Doe, Plaintiff Pro Se
123 Justice Way
Liberty City, Freedom State 12345
(555) 555-5555
jane.doe@email.com
`,
    case_caption: `Jane Doe v. Officer John Smith, et al.`,
    jurisdiction_statement: "This Court has jurisdiction under 42 U.S.C. § 1983 and 28 U.S.C. § 1331",
    filing_checklist: [
        "Review complaint for accuracy and completeness",
        "Prepare summons for each defendant (2 defendants total)",
        "Complete civil cover sheet (Form JS 44)",
        "Calculate and prepare filing fee or fee waiver application",
        "Prepare certificate of service for all defendants",
        "Make copies for your records",
        "File original with court clerk",
        "Serve each defendant according to Federal Rules"
    ],
    strategic_notes: `This complaint alleges constitutional violations under 42 U.S.C. § 1983 against 2 defendant(s). Consider consulting with a civil rights attorney before filing, especially regarding qualified immunity defenses and municipal liability issues (Monell claim). Each defendant must be properly served. Ensure all statute of limitations deadlines are met.`
};

export default function CivilRightsComplaintBuilder() {
    const { toast } = useToast();
    const [isGenerating, setIsGenerating] = useState(false);
    const [generatedComplaint, setGeneratedComplaint] = useState("");
    const [userFacts, setUserFacts] = useState("");

    const generateComplaint = async () => {
        if (userFacts.trim().length < 50) {
            toast({
                title: "More Information Needed",
                description: "Please provide a more detailed statement of facts (at least 50 characters).",
                variant: "destructive",
            });
            return;
        }

        setIsGenerating(true);
        try {
            const prompt = `Based on the following facts, generate a comprehensive federal civil rights complaint under 42 U.S.C. § 1983. The complaint should be structured for filing in a U.S. District Court and include sections for Jurisdiction, Parties, Statement of Facts, legal claims (e.g., First Amendment, Fourth Amendment), and a Prayer for Relief. Be professional, legally formatted, and thorough.

Facts provided by user:
---
${userFacts}
---`;

            const result = await InvokeLLM({ prompt });
            setGeneratedComplaint(result);
            toast({
                title: "Complaint Generated",
                description: "Your draft complaint is ready for review.",
            });
        } catch (error) {
            console.error("AI Generation Error:", error);
            toast({
                title: "Generation Failed",
                description: "The AI failed to generate the complaint. Please try again.",
                variant: "destructive",
            });
        } finally {
            setIsGenerating(false);
        }
    };

    const downloadComplaint = () => {
        const content = generatedComplaint || demoComplaint.complete_complaint; // Fallback to demo if nothing generated
        const blob = new Blob([content], { type: 'text/plain' });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `Civil_Rights_Complaint.txt`;
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
        a.remove();
        toast({
            title: "Complaint Downloaded",
            description: "A text file of the complaint has been downloaded.",
        });
    };

    return (
        <div className="p-6 space-y-8">
            <div className="max-w-6xl mx-auto">
                <div className="mb-8">
                    <div className="flex items-center gap-3 mb-4">
                        <div className="w-12 h-12 bg-gradient-to-br from-blue-600 to-slate-800 rounded-xl flex items-center justify-center">
                            <Shield className="w-7 h-7 text-white" />
                        </div>
                        <div>
                            <h1 className="text-3xl font-bold text-slate-900">Civil Rights Complaint Builder</h1>
                            <p className="text-slate-600 mt-1">Generate a federal civil rights complaint (42 U.S.C. § 1983)</p>
                        </div>
                    </div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                    <div className="lg:col-span-2 space-y-6">
                        <Card className="border-0 shadow-lg bg-white">
                            <CardHeader>
                                <CardTitle>1. Describe the Facts</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <Textarea
                                    placeholder="Provide a detailed, factual account of what happened. Include dates, locations, names of officials involved, and specific actions taken."
                                    value={userFacts}
                                    onChange={(e) => setUserFacts(e.target.value)}
                                    className="h-40"
                                />
                            </CardContent>
                            <CardFooter>
                                <Button onClick={generateComplaint} disabled={isGenerating}>
                                    {isGenerating ? "Generating..." : "Generate Complaint"}
                                </Button>
                            </CardFooter>
                        </Card>

                        <Card className="border-0 shadow-lg bg-white">
                            <CardHeader>
                                <CardTitle>2. Review Your Draft Complaint</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="bg-slate-50 p-6 rounded-lg border max-h-[40rem] overflow-y-auto">
                                    <pre className="whitespace-pre-wrap text-sm text-slate-900 font-mono leading-relaxed">
                                        {generatedComplaint || "Your generated complaint will appear here..."}
                                    </pre>
                                </div>
                            </CardContent>
                            <CardFooter className="flex gap-3">
                                <Button onClick={downloadComplaint} className="bg-green-600 hover:bg-green-700" disabled={!generatedComplaint}>
                                    <Download className="w-4 h-4 mr-2" />
                                    Download Complaint
                                </Button>
                            </CardFooter>
                        </Card>
                    </div>

                    <div className="space-y-6">
                        <Card className="border-0 shadow-lg bg-white">
                            <CardHeader>
                                <CardTitle className="flex items-center gap-2">
                                    <FileText className="w-5 h-5 text-blue-600" />
                                    Filing Checklist
                                </CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="space-y-2">
                                    {demoComplaint.filing_checklist.map((item, index) => (
                                        <div key={index} className="flex items-start gap-2">
                                            <div className="w-4 h-4 border border-slate-300 rounded mt-0.5"></div>
                                            <span className="text-sm text-slate-700">{item}</span>
                                        </div>
                                    ))}
                                </div>
                            </CardContent>
                        </Card>

                        <Card className="border-0 shadow-lg bg-white">
                            <CardHeader>
                                <CardTitle className="flex items-center gap-2">
                                    <Scale className="w-5 h-5 text-amber-600" />
                                    Strategic Notes
                                </CardTitle>
                            </CardHeader>
                            <CardContent>
                                <p className="text-sm text-slate-700 leading-relaxed">
                                    This complaint alleges constitutional violations under 42 U.S.C. § 1983. Consider consulting with a civil rights attorney before filing, especially regarding qualified immunity defenses and municipal liability issues (Monell claim). Each defendant must be properly served. Ensure all statute of limitations deadlines are met.
                                </p>
                            </CardContent>
                        </Card>
                        
                        <Alert className="bg-amber-50 border-amber-200">
                            <AlertTriangle className="h-4 w-4 text-amber-600" />
                            <AlertDescription className="text-amber-800 text-xs">
                                <strong>Important:</strong> This is an AI-generated draft for informational purposes. Have any real complaint reviewed by a qualified civil rights attorney before filing.
                            </AlertDescription>
                        </Alert>
                    </div>
                </div>
            </div>
        </div>
    );
}

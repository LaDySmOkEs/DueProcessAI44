import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Shield, CheckCircle, XCircle, RotateCcw } from "lucide-react";

const scenarios = [
  {
    id: 1,
    title: "Traffic Stop",
    situation: "You've been pulled over for speeding. The officer approaches your window and asks, 'Do you know why I stopped you?'",
    options: [
      { text: "No, officer, I don't know why you stopped me.", correct: true, explanation: "Correct! This avoids admitting guilt while being respectful." },
      { text: "I was probably going a little fast.", correct: false, explanation: "This admits guilt and can be used against you in court." },
      { text: "I wasn't doing anything wrong!", correct: false, explanation: "This can escalate the situation and appears confrontational." }
    ],
    rightToKnow: "You have the right to remain silent and not incriminate yourself (5th Amendment)."
  },
  {
    id: 2,
    title: "Consent to Search Vehicle",
    situation: "During a traffic stop, the officer asks, 'Do you mind if I search your car?'",
    options: [
      { text: "I do not consent to a search.", correct: true, explanation: "Correct! Clearly assert your 4th Amendment rights." },
      { text: "Sure, I have nothing to hide.", correct: false, explanation: "You're giving up your constitutional protection against unreasonable searches." },
      { text: "Go ahead, but be quick about it.", correct: false, explanation: "This is giving consent and waiving your rights." }
    ],
    rightToKnow: "You have the right to refuse consent to search your vehicle (4th Amendment)."
  },
  {
    id: 3,
    title: "Police at Your Door",
    situation: "Police officers come to your home and ask to come inside to 'ask a few questions.'",
    options: [
      { text: "I prefer to speak with you outside. May I see your warrant?", correct: true, explanation: "Correct! Protect your home and ask for proper legal authority." },
      { text: "Sure, come on in.", correct: false, explanation: "You're allowing entry without a warrant and giving up strong constitutional protections." },
      { text: "What's this about? Come in and we'll talk.", correct: false, explanation: "Again, you're allowing warrantless entry to your home." }
    ],
    rightToKnow: "Your home has the strongest 4th Amendment protections. Police generally need a warrant to enter."
  }
];

export default function ScenarioTrainer() {
  const [currentScenario, setCurrentScenario] = useState(0);
  const [selectedOption, setSelectedOption] = useState(null);
  const [showResult, setShowResult] = useState(false);
  const [score, setScore] = useState({ correct: 0, total: 0 });

  const handleOptionSelect = (optionIndex) => {
    if (showResult) return;
    
    setSelectedOption(optionIndex);
    setShowResult(true);
    
    const isCorrect = scenarios[currentScenario].options[optionIndex].correct;
    setScore(prev => ({
      correct: prev.correct + (isCorrect ? 1 : 0),
      total: prev.total + 1
    }));
  };

  const nextScenario = () => {
    if (currentScenario < scenarios.length - 1) {
      setCurrentScenario(prev => prev + 1);
      setSelectedOption(null);
      setShowResult(false);
    }
  };

  const resetTraining = () => {
    setCurrentScenario(0);
    setSelectedOption(null);
    setShowResult(false);
    setScore({ correct: 0, total: 0 });
  };

  const scenario = scenarios[currentScenario];
  const selectedAnswer = selectedOption !== null ? scenario.options[selectedOption] : null;

  return (
    <div className="max-w-4xl mx-auto">
      <Card className="border-0 shadow-lg bg-white">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-xl font-bold text-slate-900 flex items-center gap-2">
              <Shield className="w-6 h-6 text-blue-600" />
              Scenario Training
            </CardTitle>
            <div className="flex items-center gap-4">
              <Badge variant="outline" className="bg-slate-50">
                Score: {score.correct}/{score.total}
              </Badge>
              <Badge variant="outline" className="bg-blue-50 text-blue-700">
                {currentScenario + 1} of {scenarios.length}
              </Badge>
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Scenario */}
          <div className="bg-slate-50 p-6 rounded-lg">
            <h3 className="font-bold text-slate-900 mb-3">{scenario.title}</h3>
            <p className="text-slate-700 leading-relaxed">{scenario.situation}</p>
          </div>

          {/* Options */}
          <div className="space-y-3">
            <h4 className="font-semibold text-slate-900">How should you respond?</h4>
            {scenario.options.map((option, index) => (
              <Button
                key={index}
                variant="outline"
                className={`w-full justify-start p-4 h-auto text-left transition-all duration-200 ${
                  selectedOption === index
                    ? option.correct
                      ? 'border-green-500 bg-green-50 text-green-900'
                      : 'border-red-500 bg-red-50 text-red-900'
                    : showResult && option.correct
                    ? 'border-green-500 bg-green-50 text-green-900'
                    : 'hover:bg-slate-50'
                }`}
                onClick={() => handleOptionSelect(index)}
                disabled={showResult}
              >
                <div className="flex items-start gap-3 w-full">
                  <div className="flex-shrink-0 mt-1">
                    {showResult && (
                      selectedOption === index
                        ? option.correct
                          ? <CheckCircle className="w-5 h-5 text-green-600" />
                          : <XCircle className="w-5 h-5 text-red-600" />
                        : option.correct
                        ? <CheckCircle className="w-5 h-5 text-green-600" />
                        : <div className="w-5 h-5 rounded-full border-2 border-slate-300" />
                    )}
                  </div>
                  <div className="flex-1">
                    <p className="font-medium">{option.text}</p>
                    {showResult && (selectedOption === index || option.correct) && (
                      <p className="text-sm mt-2 opacity-90">{option.explanation}</p>
                    )}
                  </div>
                </div>
              </Button>
            ))}
          </div>

          {/* Legal Context */}
          {showResult && (
            <div className="bg-blue-50 border border-blue-200 p-4 rounded-lg">
              <h4 className="font-semibold text-blue-900 mb-2">Your Rights:</h4>
              <p className="text-blue-800 text-sm">{scenario.rightToKnow}</p>
            </div>
          )}

          {/* Navigation */}
          <div className="flex justify-between items-center pt-4 border-t border-slate-200">
            <Button
              variant="outline"
              onClick={resetTraining}
              className="gap-2"
            >
              <RotateCcw className="w-4 h-4" />
              Reset Training
            </Button>
            
            <div className="flex gap-2">
              {currentScenario < scenarios.length - 1 ? (
                <Button
                  onClick={nextScenario}
                  disabled={!showResult}
                  className="bg-blue-600 hover:bg-blue-700"
                >
                  Next Scenario
                </Button>
              ) : (
                showResult && (
                  <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200 px-4 py-2">
                    Training Complete! Final Score: {score.correct}/{score.total}
                  </Badge>
                )
              )}
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
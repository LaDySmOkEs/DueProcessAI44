import React, { useState, useEffect, useRef } from 'react';
import { useForm, Controller } from 'react-hook-form';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { LegalCase } from "@/api/entities";
import { FileUp, FileCheck, Loader2, AlertTriangle } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";

export default function DocumentUpload({ onFileSelect, onAnalyze, isAnalyzing }) {
    const { register, handleSubmit, control, formState: { errors } } = useForm();
    const [selectedFile, setSelectedFile] = useState(null);
    const [cases, setCases] = useState([]);
    const [fileError, setFileError] = useState(null);
    const fileInputRef = useRef(null);

    useEffect(() => {
        const fetchCases = async () => {
            try {
                const caseList = await LegalCase.list();
                setCases(caseList);
            } catch (err) {
                console.error("Failed to fetch cases:", err);
            }
        };
        fetchCases();
    }, []);

    const handleFileChange = (e) => {
        const file = e.target.files[0];
        setFileError(null);
        
        if (file) {
            setSelectedFile(file);
            if (onFileSelect) {
                onFileSelect(file);
            }
        } else {
            setSelectedFile(null);
            if (onFileSelect) {
                onFileSelect(null);
            }
        }
    };
    
    const onSubmit = (data) => {
        if (!selectedFile) {
            setFileError('Please select a file to analyze.');
            return;
        }
        setFileError(null); // Clear previous errors
        if (onAnalyze) {
            onAnalyze(data);
        }
    };

    const triggerFileSelect = () => {
        fileInputRef.current?.click();
    };

    return (
        <form onSubmit={handleSubmit(onSubmit)}>
            <Card className="border-0 shadow-lg bg-white">
                <CardHeader>
                    <CardTitle className="text-xl font-bold text-slate-900">1. Upload Document</CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                    {/* File Input */}
                    <div
                        className="p-6 border-2 border-dashed border-slate-300 rounded-lg text-center cursor-pointer hover:bg-slate-50 transition-colors"
                        onClick={triggerFileSelect}
                    >
                        <Input
                            id="file-upload"
                            ref={fileInputRef}
                            type="file"
                            className="hidden"
                            onChange={handleFileChange}
                        />
                        {selectedFile ? (
                            <div className="space-y-2">
                                <div className="mx-auto w-12 h-12 flex items-center justify-center bg-green-100 rounded-full">
                                    <FileCheck className="w-6 h-6 text-green-600" />
                                </div>
                                <p className="font-semibold text-slate-700">{selectedFile.name}</p>
                                <p className="text-xs text-slate-500">
                                    {(selectedFile.size / 1024 / 1024).toFixed(2)} MB
                                </p>
                            </div>
                        ) : (
                            <div className="space-y-2">
                                <div className="mx-auto w-12 h-12 flex items-center justify-center bg-slate-100 rounded-full">
                                    <FileUp className="w-6 h-6 text-slate-500" />
                                </div>
                                <p className="font-semibold text-slate-700">Click to upload a file</p>
                                <p className="text-xs text-slate-500">All document and image types supported</p>
                            </div>
                        )}
                    </div>

                    {/* File Error Alert */}
                    {fileError && (
                        <Alert className="bg-red-50 border-red-200">
                            <AlertTriangle className="h-4 w-4 text-red-600" />
                            <AlertDescription className="text-red-800">
                                {fileError}
                            </AlertDescription>
                        </Alert>
                    )}

                    {/* Form Fields */}
                    <div className="space-y-4">
                        <div>
                            <Label htmlFor="document_name">Document Name</Label>
                            <Input 
                                id="document_name" 
                                {...register("document_name", { required: "Document name is required" })} 
                                placeholder="e.g., Police Report #12345" 
                            />
                            {errors.document_name && <p className="text-red-500 text-xs mt-1">{errors.document_name.message}</p>}
                        </div>
                        
                        <div>
                            <Label htmlFor="document_type">Document Type</Label>
                            <Controller
                                name="document_type"
                                control={control}
                                rules={{ required: "Please select a document type" }}
                                render={({ field }) => (
                                    <Select onValueChange={field.onChange} value={field.value}>
                                        <SelectTrigger>
                                            <SelectValue placeholder="Select document type" />
                                        </SelectTrigger>
                                        <SelectContent>
                                            <SelectItem value="police_report">Police Report</SelectItem>
                                            <SelectItem value="motion">Motion</SelectItem>
                                            <SelectItem value="affidavit">Affidavit</SelectItem>
                                            <SelectItem value="discovery">Discovery</SelectItem>
                                            <SelectItem value="evidence">Evidence</SelectItem>
                                            <SelectItem value="other">Other</SelectItem>
                                        </SelectContent>
                                    </Select>
                                )}
                            />
                            {errors.document_type && <p className="text-red-500 text-xs mt-1">{errors.document_type.message}</p>}
                        </div>

                        <div>
                            <Label htmlFor="case_id">Link to Case (Optional)</Label>
                            <Controller
                                name="case_id"
                                control={control}
                                render={({ field }) => (
                                    <Select onValueChange={field.onChange} value={field.value}>
                                        <SelectTrigger>
                                            <SelectValue placeholder="Select a case" />
                                        </SelectTrigger>
                                        <SelectContent>
                                            <SelectItem value={null}>No case selected</SelectItem>
                                            {cases.map((c) => (
                                                <SelectItem key={c.id} value={c.id}>{c.case_name}</SelectItem>
                                            ))}
                                        </SelectContent>
                                    </Select>
                                )}
                            />
                        </div>
                    </div>
                </CardContent>
                <CardFooter>
                    <Button 
                        type="submit" 
                        className="w-full bg-teal-600 hover:bg-teal-700" 
                        disabled={!selectedFile || isAnalyzing || fileError}
                    >
                        {isAnalyzing ? (
                            <>
                                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                Analyzing...
                            </>
                        ) : (
                            'Analyze Document'
                        )}
                    </Button>
                </CardFooter>
            </Card>
        </form>
    );
}
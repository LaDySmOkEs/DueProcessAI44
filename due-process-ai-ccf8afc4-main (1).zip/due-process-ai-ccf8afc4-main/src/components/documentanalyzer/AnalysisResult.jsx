import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { AlertCircle, CheckCircle, FileText, Loader2, Link as LinkIcon, Download } from 'lucide-react';
import { Button } from "@/components/ui/button";
import ReactMarkdown from 'react-markdown';
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function AnalysisResult({ result, isAnalyzing, showError }) {
  if (isAnalyzing && !result) {
    return (
      <Card className="border-0 shadow-lg bg-white">
        <CardHeader>
          <CardTitle>Analyzing Document...</CardTitle>
        </CardHeader>
        <CardContent className="text-center p-12">
          <Loader2 className="w-12 h-12 text-slate-500 mx-auto animate-spin mb-4" />
          <p className="text-slate-600">The AI is performing a deep analysis. This may take a moment for larger documents.</p>
        </CardContent>
      </Card>
    );
  }

  if (!result) {
    return (
      <Card className="border-0 shadow-lg bg-white">
        <CardHeader>
          <CardTitle>Awaiting Analysis</CardTitle>
        </CardHeader>
        <CardContent className="text-center p-12">
          <FileText className="w-12 h-12 text-slate-400 mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-slate-900 mb-2">Upload a document to begin</h3>
          <p className="text-slate-600 text-sm">
            Your AI-powered analysis report will appear here once you submit a document.
          </p>
        </CardContent>
      </Card>
    );
  }

  const { document_name, ai_summary, ai_analysis, error, saved_document_id } = result;

  if (error) {
    return (
      <Card className={`border-2 shadow-lg bg-white ${showError ? 'border-red-300' : ''}`}>
        <CardHeader className="bg-red-50">
          <CardTitle className="flex items-center gap-2 text-red-800">
            <AlertCircle className="w-6 h-6" />
            Analysis Failed
          </CardTitle>
        </CardHeader>
        <CardContent className="p-6">
          <p className="font-semibold text-slate-900 mb-2">Document: {document_name}</p>
          <p className="text-red-700">{ai_summary}</p>
        </CardContent>
      </Card>
    );
  }

  const isVideoAnalysis = result.document_type === 'video_evidence';

  const renderDocumentAnalysis = () => (
    <>
      {/* Key Entities */}
      {ai_analysis?.key_entities && (
        <div>
          <h4 className="font-semibold text-slate-800 mb-2">Key Entities</h4>
          <div className="space-y-2 text-sm">
            <p><strong>People:</strong> {ai_analysis.key_entities.people?.map(p => p.name).join(', ') || 'N/A'}</p>
            <p><strong>Dates:</strong> {ai_analysis.key_entities.dates?.map(d => d.date).join(', ') || 'N/A'}</p>
            <p><strong>Locations:</strong> {ai_analysis.key_entities.locations?.map(l => l.location).join(', ') || 'N/A'}</p>
          </div>
        </div>
      )}

      {/* Critical Analysis */}
      {ai_analysis?.critical_analysis && (
        <div>
          <h4 className="font-semibold text-slate-800 mb-2">Critical Analysis</h4>
          <div className="space-y-2 text-sm">
            {ai_analysis.critical_analysis.procedural_violations?.length > 0 && (
              <div className="p-2 bg-red-50 rounded-md">
                <p className="font-bold text-red-700">Procedural Violations Found:</p>
                <ul className="list-disc list-inside">
                  {ai_analysis.critical_analysis.procedural_violations.map((v, i) => <li key={i}>{v.violation_type}: {v.evidence_of_violation}</li>)}
                </ul>
              </div>
            )}
             {ai_analysis.critical_analysis.inconsistencies?.length > 0 && (
              <div className="p-2 bg-yellow-50 rounded-md">
                <p className="font-bold text-yellow-700">Inconsistencies Found:</p>
                <ul className="list-disc list-inside">
                  {ai_analysis.critical_analysis.inconsistencies.map((inc, i) => <li key={i}>{inc.inconsistency_type}: {inc.detailed_description}</li>)}
                </ul>
              </div>
            )}
          </div>
        </div>
      )}
    </>
  );

  const renderVideoAnalysis = () => (
    <>
      {ai_analysis?.key_events && ai_analysis.key_events.length > 0 && (
        <div>
          <h4 className="font-semibold text-slate-800 mb-2">Timeline of Key Events</h4>
          <div className="space-y-2 text-sm max-h-40 overflow-y-auto pr-2">
            {ai_analysis.key_events.map((event, i) => (
              <p key={i}><strong>{event.timestamp}:</strong> {event.description}</p>
            ))}
          </div>
        </div>
      )}
      {ai_analysis?.identified_violations && ai_analysis.identified_violations.length > 0 && (
        <div className="p-3 bg-red-50 rounded-md">
          <h4 className="font-bold text-red-700 mb-2">Identified Violations</h4>
          <div className="space-y-2 text-sm">
            {ai_analysis.identified_violations.map((v, i) => (
              <div key={i}>
                <p><strong>{v.violation_type} at {v.timestamp_of_violation}</strong></p>
                <p className="pl-2">Evidence: {v.supporting_evidence}</p>
                <p className="pl-2">Implication: {v.constitutional_implication}</p>
              </div>
            ))}
          </div>
        </div>
      )}
      {ai_analysis?.full_transcript && (
         <div>
          <h4 className="font-semibold text-slate-800 mb-2">Full Transcript</h4>
          <div className="text-sm bg-slate-50 p-3 rounded-md max-h-60 overflow-y-auto">
            <ReactMarkdown className="prose prose-sm">{ai_analysis.full_transcript}</ReactMarkdown>
          </div>
        </div>
      )}
    </>
  );

  return (
    <Card className={`border-0 shadow-lg bg-white ${showError ? 'border-red-300' : ''}`}>
      <CardHeader className="bg-slate-50">
        <div className="flex justify-between items-center">
          <CardTitle className="flex items-center gap-2 text-slate-800">
            <CheckCircle className="w-6 h-6 text-green-600" />
            Analysis Complete
          </CardTitle>
          {saved_document_id && (
            <Link to={createPageUrl(`DocumentManager?docId=${saved_document_id}`)}>
              <Button size="sm" variant="outline" className="gap-2">
                <LinkIcon className="w-4 h-4" /> Go to Document
              </Button>
            </Link>
          )}
        </div>
      </CardHeader>
      <CardContent className="p-6 space-y-4">
        <div>
          <p className="text-sm font-medium text-slate-600">Document Name</p>
          <p className="font-semibold text-slate-900">{document_name}</p>
        </div>
        <div>
          <p className="text-sm font-medium text-slate-600">AI Summary</p>
          <ReactMarkdown className="prose prose-sm max-w-none">{ai_summary}</ReactMarkdown>
        </div>

        {isVideoAnalysis ? renderVideoAnalysis() : renderDocumentAnalysis()}
        
      </CardContent>
    </Card>
  );
}
import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

export default function StatsCard({ title, value, icon: Icon, bgColor, description }) {
  const colorMap = {
    'bg-blue-500': 'bg-amber-500',
    'bg-red-500': 'bg-red-500',
    'bg-orange-500': 'bg-amber-600',
    'bg-green-500': 'bg-slate-600'
  };

  const mappedColor = colorMap[bgColor] || bgColor;

  return (
    <Card className="relative overflow-hidden border-0 shadow-lg bg-white">
      <div className={`absolute top-0 right-0 w-32 h-32 transform translate-x-8 -translate-y-8 ${mappedColor} rounded-full opacity-10`} />
      <CardContent className="p-6">
        <div className="flex justify-between items-start mb-4">
          <div className="flex-1">
            <p className="text-sm font-medium text-slate-600 mb-2">{title}</p>
            <p className="text-3xl font-bold text-slate-900">{value}</p>
          </div>
          <div className={`p-3 rounded-xl ${mappedColor} bg-opacity-10`}>
            <Icon className={`w-6 h-6 ${mappedColor.replace('bg-', 'text-')}`} />
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Badge variant="secondary" className="text-xs font-medium bg-amber-50 text-amber-700">
            {description}
          </Badge>
        </div>
      </CardContent>
    </Card>
  );
}
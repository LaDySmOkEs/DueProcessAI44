import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { User } from "@/api/entities";
import { createCheckoutSession } from "@/api/functions";
import { useToast } from "@/components/ui/use-toast";
import { Crown, Zap, Clock, Shield, Star, Loader2 } from "lucide-react";

export const FEATURE_LIMITS = {
    free: {
        ai_operations: 5,
        document_analysis: false,
        document_generation: false,
        case_strategy: false,
        courtroom_simulator: false
    },
    trial: {
        ai_operations: 50,
        document_analysis: true,
        document_generation: true,
        case_strategy: true,
        courtroom_simulator: true
    },
    basic: {
        ai_operations: 100,
        document_analysis: true,
        document_generation: true,
        case_strategy: true,
        courtroom_simulator: false
    },
    premium: {
        ai_operations: 1000,
        document_analysis: true,
        document_generation: true,
        case_strategy: true,
        courtroom_simulator: true
    }
};

export const PRICE_IDS = {
    basic: 'price_1Rb9cHGKH727ZIVgLN4Veem7',
    premium: 'price_1Rb9dJGKH727ZIVgTxb3MhQV'
};

export default function SubscriptionGate({ feature, children, fallbackContent }) {
    const [user, setUser] = useState(null);
    const [canAccess, setCanAccess] = useState(false);
    const [loading, setLoading] = useState(true);
    const [isSubscribing, setIsSubscribing] = useState(false);
    const { toast } = useToast();

    useEffect(() => {
        checkAccess();
    }, [feature]);

    const checkAccess = async () => {
        setLoading(true);
        try {
            const userData = await User.me();
            setUser(userData);
            
            let tier = userData.subscription_tier || 'free';
            
            // Check if trial expired
            if (tier === 'trial' && userData.trial_start_date) {
                const trialStart = new Date(userData.trial_start_date);
                const daysSinceStart = (Date.now() - trialStart.getTime()) / (1000 * 60 * 60 * 24);
                if (daysSinceStart > 1) {
                    await User.updateMyUserData({ subscription_tier: 'free' });
                    tier = 'free';
                }
            }

            const limits = FEATURE_LIMITS[tier];
            if (feature === 'ai_operation') {
                setCanAccess(limits.ai_operations > (userData.ai_usage_count || 0));
            } else {
                setCanAccess(limits[feature] === true);
            }
        } catch (error) {
            console.error('Access check failed:', error);
            setCanAccess(false);
        } finally {
            setLoading(false);
        }
    };

    const handleSubscribe = async (tier) => {
        setIsSubscribing(tier);
        try {
            const priceId = PRICE_IDS[tier];
            if (!priceId) {
                throw new Error("Price ID not configured for this plan.");
            }
            const { data } = await createCheckoutSession({ priceId });
            if (data && data.url) {
                window.location.href = data.url;
            } else {
                throw new Error("Could not initiate checkout. No URL received.");
            }
        } catch (error) {
            console.error("Subscription Error:", error);
            toast({
                title: "Subscription Failed",
                description: error.message || "Please try again later.",
                variant: "destructive"
            });
            setIsSubscribing(false);
        }
    };

    const startTrial = async () => {
        setIsSubscribing('trial');
        try {
            await User.updateMyUserData({
                subscription_tier: 'trial',
                trial_start_date: new Date().toISOString().split('T')[0],
                trial_used: true
            });
            toast({
                title: "Trial Started!",
                description: "You now have 24-hour access to all premium features.",
            });
            window.location.reload();
        } catch (error) {
            console.error('Trial start failed:', error);
            toast({
                title: "Trial Start Failed",
                description: "Could not start trial. Please try again.",
                variant: "destructive"
            });
        } finally {
            setIsSubscribing(false);
        }
    };

    if (loading) {
        return (
            <div className="flex items-center justify-center p-10">
                <Loader2 className="w-8 h-8 animate-spin text-slate-500" />
            </div>
        );
    }

    if (canAccess) {
        return children;
    }

    const tier = user?.subscription_tier || 'free';
    const hasUsedTrial = user?.trial_used || false;

    return (
        <Card className="border-2 border-amber-200 bg-gradient-to-br from-amber-50 to-orange-50">
            <CardHeader className="text-center">
                <div className="w-16 h-16 bg-gradient-to-br from-amber-500 to-orange-600 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Crown className="w-8 h-8 text-white" />
                </div>
                <CardTitle className="text-xl text-slate-900">Upgrade Required</CardTitle>
                <p className="text-slate-600">This advanced AI feature requires a subscription</p>
            </CardHeader>
            <CardContent className="space-y-6">
                <div className="text-center">
                    <Badge variant="outline" className="bg-white">
                        Current Plan: {tier.charAt(0).toUpperCase() + tier.slice(1)}
                    </Badge>
                </div>

                {!hasUsedTrial && tier === 'free' && (
                    <Alert className="bg-blue-50 border-blue-200">
                        <Clock className="h-4 w-4 text-blue-600" />
                        <AlertDescription className="text-blue-800">
                            <div className="font-semibold mb-2">🎉 Start Your Free 24-Hour Trial!</div>
                            <p className="text-sm mb-3">Get instant access to all AI features with no commitment.</p>
                            <Button 
                                onClick={startTrial} 
                                className="bg-blue-600 hover:bg-blue-700 w-full"
                                disabled={isSubscribing}
                            >
                                {isSubscribing === 'trial' ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                                Start Free Trial Now
                            </Button>
                        </AlertDescription>
                    </Alert>
                )}

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <Card className="border-slate-200">
                        <CardHeader className="pb-4">
                            <div className="flex items-center gap-2">
                                <Zap className="w-5 h-5 text-blue-600" />
                                <CardTitle className="text-lg">Basic Plan</CardTitle>
                            </div>
                            <div className="text-2xl font-bold text-slate-900">$15<span className="text-sm font-normal text-slate-600">/month</span></div>
                        </CardHeader>
                        <CardContent className="space-y-3 text-sm">
                            <p>100 AI operations/month</p>
                            <p>Document analysis & generation</p>
                            <p>AI case strategy</p>
                            <Button 
                                className="w-full mt-4 bg-blue-600 hover:bg-blue-700"
                                onClick={() => handleSubscribe('basic')}
                                disabled={isSubscribing}
                            >
                                {isSubscribing === 'basic' ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                                Subscribe - $15/mo
                            </Button>
                        </CardContent>
                    </Card>

                    <Card className="border-amber-300 relative overflow-hidden">
                        <div className="absolute top-0 right-0 bg-gradient-to-l from-amber-500 to-orange-500 text-white px-3 py-1 text-xs font-bold">
                            MOST POPULAR
                        </div>
                        <CardHeader className="pb-4">
                            <div className="flex items-center gap-2">
                                <Star className="w-5 h-5 text-amber-600" />
                                <CardTitle className="text-lg">Premium Plan</CardTitle>
                            </div>
                            <div className="text-2xl font-bold text-slate-900">$30<span className="text-sm font-normal text-slate-600">/month</span></div>
                        </CardHeader>
                        <CardContent className="space-y-3 text-sm">
                            <p>1,000 AI operations/month</p>
                            <p>All document tools</p>
                            <p>Advanced case strategy</p>
                            <p>Courtroom simulator</p>
                            <Button 
                                className="w-full mt-4 bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-700 hover:to-orange-700"
                                onClick={() => handleSubscribe('premium')}
                                disabled={isSubscribing}
                            >
                                {isSubscribing === 'premium' ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                                Subscribe - $30/mo
                            </Button>
                        </CardContent>
                    </Card>
                </div>

                <Alert className="bg-green-50 border-green-200">
                    <Shield className="h-4 w-4 text-green-600" />
                    <AlertDescription className="text-green-800">
                        <div className="font-semibold mb-1">🔓 Always Free Tools</div>
                        <p className="text-sm">Accountability tools, incident logging, and rights education remain completely free.</p>
                    </AlertDescription>
                </Alert>

                {fallbackContent && (
                    <div className="pt-4 border-t border-slate-200">
                        {fallbackContent}
                    </div>
                )}
            </CardContent>
        </Card>
    );
}
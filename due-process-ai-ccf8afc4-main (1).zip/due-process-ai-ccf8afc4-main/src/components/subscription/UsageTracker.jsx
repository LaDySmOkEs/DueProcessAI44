import React, { useState, useEffect } from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { User } from "@/api/entities";
import { Zap, Crown } from "lucide-react";

export default function UsageTracker() {
    const [user, setUser] = useState(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        loadUserData();
    }, []);

    const loadUserData = async () => {
        try {
            const userData = await User.me();
            setUser(userData);
        } catch (error) {
            // User not logged in, do nothing
        } finally {
            setLoading(false);
        }
    };

    if (loading || !user) return null;

    const tier = user.subscription_tier || 'free';
    const usage = user.ai_usage_count || 0;
    
    const limits = {
        free: 0,
        trial: 50,
        basic: 100,
        premium: 1000
    };

    const limit = limits[tier];
    const percentage = limit > 0 ? Math.min((usage / limit) * 100, 100) : 0;

    // Don't show for free users (they can't use AI anyway) or if there's no limit
    if (tier === 'free' || limit === 0) return null;

    return (
        <Card className="border-0 shadow-sm bg-white">
            <CardContent className="p-4">
                <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                        <Zap className="w-4 h-4 text-blue-600" />
                        <span className="text-sm font-medium text-slate-700">AI Usage This Month</span>
                    </div>
                    <Badge variant="outline" className={`
                        ${tier === 'premium' ? 'bg-amber-50 text-amber-700 border-amber-300' : ''}
                        ${tier === 'basic' ? 'bg-blue-50 text-blue-700 border-blue-300' : ''}
                        ${tier === 'trial' ? 'bg-green-50 text-green-700 border-green-300' : ''}
                    `}>
                        {tier === 'premium' && <Crown className="w-3 h-3 mr-1" />}
                        {tier.charAt(0).toUpperCase() + tier.slice(1)}
                    </Badge>
                </div>
                
                <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                        <span className="text-slate-600">{usage} used</span>
                        <span className="text-slate-600">{limit} limit</span>
                    </div>
                    <Progress 
                        value={percentage} 
                        className="h-2"
                        indicatorClassName={
                            percentage > 90 ? 'bg-red-500' : 
                            percentage > 75 ? 'bg-yellow-500' : 'bg-green-500'
                        }
                    />
                    {percentage > 90 && (
                        <p className="text-xs text-red-600">⚠️ Running low on AI operations</p>
                    )}
                </div>
            </CardContent>
        </Card>
    );
}

import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Bot, Lightbulb, FileSignature, AlertCircle, Info, Loader2, Wifi, WifiOff } from 'lucide-react';
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Textarea } from '@/components/ui/textarea';
import { InvokeLLM } from "@/api/integrations";
import { useToast } from "@/components/ui/use-toast";

const suggestionSchema = {
    type: "object",
    properties: {
        suggestions: {
            type: "array",
            items: {
                type: "object",
                properties: {
                    title: { type: "string" },
                    reasoning: { type: "string" },
                    priority: { type: "string", enum: ["High", "Medium", "Low"] },
                    document_type: { 
                        type: "string", 
                        enum: ["civil_rights_complaint", "motion_to_dismiss", "discovery_request", "affidavit", "cease_desist", "motion_compel", "custody_agreement", "breach_of_contract_notice"],
                        description: "The type of document to generate"
                    }
                },
                required: ["title", "reasoning", "priority", "document_type"]
            }
        }
    },
    required: ["suggestions"]
};

const priorityMap = {
  High: { class: "bg-red-100 text-red-800 border-red-200" },
  Medium: { class: "bg-orange-100 text-orange-800 border-orange-200" },
  Low: { class: "bg-yellow-100 text-yellow-800 border-yellow-200" }
};

// Fallback suggestions based on keywords
const getFallbackSuggestions = (caseSummary) => {
    const summary = caseSummary.toLowerCase();
    const suggestions = [];

    if (summary.includes('contract') || summary.includes('breach') || summary.includes('agreement') || summary.includes('failed to perform')) {
        suggestions.push({
            title: "Breach of Contract Notice",
            reasoning: "Your case involves a potential breach of contract, which requires a formal notice to the other party.",
            priority: "High",
            document_type: "breach_of_contract_notice"
        });
    }

    if (summary.includes('custody') || summary.includes('child') || summary.includes('visitation')) {
        suggestions.push({
            title: "Child Custody Agreement",
            reasoning: "Your case involves child custody arrangements, which requires a formal custody agreement.",
            priority: "High",
            document_type: "custody_agreement"
        });
    }

    if (summary.includes('police') || summary.includes('officer') || summary.includes('arrest') || summary.includes('search')) {
        suggestions.push({
            title: "Civil Rights Complaint",
            reasoning: "Your case involves potential police misconduct or constitutional violations.",
            priority: "High",
            document_type: "civil_rights_complaint"
        });
    }

    if (summary.includes('court') || summary.includes('hearing') || summary.includes('motion') || summary.includes('dismiss')) {
        suggestions.push({
            title: "Motion to Dismiss",
            reasoning: "Court proceedings may require motions to address legal issues.",
            priority: "Medium",
            document_type: "motion_to_dismiss"
        });
    }

    if (summary.includes('evidence') || summary.includes('document') || summary.includes('discovery')) {
        suggestions.push({
            title: "Discovery Request",
            reasoning: "Your case may benefit from requesting documents or information from the opposing party.",
            priority: "Medium",
            document_type: "discovery_request"
        });
    }

    if (summary.includes('witness') || summary.includes('facts') || summary.includes('sworn')) {
        suggestions.push({
            title: "Affidavit of Facts",
            reasoning: "Important facts in your case should be documented in a sworn statement.",
            priority: "Medium",
            document_type: "affidavit"
        });
    }

    // Default fallback if no keywords match
    if (suggestions.length === 0) {
        suggestions.push({
            title: "Affidavit of Facts",
            reasoning: "Document the key facts of your case in a sworn statement.",
            priority: "Medium",
            document_type: "affidavit"
        });
    }

    return suggestions;
};

export default function SmartDocumentSuggestions({ onGenerate }) {
    const [caseSummary, setCaseSummary] = useState("");
    const [suggestions, setSuggestions] = useState([]);
    const [isLoading, setIsLoading] = useState(false);
    const [isUsingFallback, setIsUsingFallback] = useState(false);
    const { toast } = useToast();

    const getSuggestions = async () => {
        if (caseSummary.trim().length < 20) {
            toast({
                title: "More Information Needed",
                description: "Please provide more details about your case for accurate recommendations.",
                variant: "destructive"
            });
            return;
        }

        setIsLoading(true);
        setSuggestions([]);
        setIsUsingFallback(false);
        
        try {
            // Try AI analysis first
            const prompt = `Analyze this case and recommend 1-3 most suitable documents. Be concise.

Case: ${caseSummary.substring(0, 500)}`;

            const result = await InvokeLLM({
                prompt,
                response_json_schema: suggestionSchema
            });
            
            setSuggestions(result.suggestions || []);
            toast({ 
                title: "AI Analysis Complete", 
                description: "Smart recommendations generated successfully." 
            });
            
        } catch (error) {
            console.error("AI analysis failed, using fallback:", error);
            
            // Use fallback system
            const fallbackSuggestions = getFallbackSuggestions(caseSummary);
            setSuggestions(fallbackSuggestions);
            setIsUsingFallback(true);
            
            toast({
                title: "Using Smart Fallback",
                description: "AI is temporarily unavailable, but we've analyzed your case using keyword matching.",
                variant: "default"
            });
        } finally {
            setIsLoading(false);
        }
    };

  return (
    <Card className="border-0 shadow-lg bg-white h-full">
      <CardHeader>
        <div className="flex items-center gap-3">
          {isUsingFallback ? (
            <WifiOff className="w-6 h-6 text-orange-600" />
          ) : (
            <Bot className="w-6 h-6 text-blue-600" />
          )}
          <CardTitle>
            {isUsingFallback ? "Smart Keyword Analysis" : "AI-Powered Case Strategist"}
          </CardTitle>
        </div>
        <p className="text-slate-600 text-sm">
          {isUsingFallback 
            ? "AI temporarily unavailable - using intelligent keyword matching" 
            : "Get instant document recommendations based on your case facts."
          }
        </p>
      </CardHeader>
      <CardContent className="space-y-6">
        <div>
            <label htmlFor="case-summary" className="text-sm font-medium text-slate-700 block mb-2">
                Your Case Summary:
            </label>
            <Textarea 
                id="case-summary"
                placeholder="Describe your case in detail. The more facts you provide, the better the recommendations will be."
                value={caseSummary}
                onChange={(e) => setCaseSummary(e.target.value)}
                className="h-32"
            />
            <Button onClick={getSuggestions} disabled={isLoading} className="mt-3 w-full">
                {isLoading ? (
                    <>
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        Analyzing...
                    </>
                ) : (
                    <>
                        <Lightbulb className="w-4 h-4 mr-2" />
                        Get Document Suggestions
                    </>
                )}
            </Button>
        </div>

        {isUsingFallback && (
            <Alert className="bg-orange-50 border-orange-200">
                <WifiOff className="h-4 w-4 text-orange-600" />
                <AlertTitle className="text-orange-900">Using Fallback Analysis</AlertTitle>
                <AlertDescription className="text-orange-800">
                    AI service is temporarily unavailable. Recommendations are based on intelligent keyword analysis of your case.
                </AlertDescription>
            </Alert>
        )}

        <div>
          <h3 className="text-base font-semibold text-slate-900 mb-3 flex items-center gap-2">
            <Lightbulb className="w-5 h-5 text-amber-500" />
            Document Recommendations
          </h3>
          <div className="space-y-3">
            {suggestions.length > 0 ? (
              suggestions.map((suggestion, index) => (
                <Card key={index} className="border-slate-200 hover:shadow-md transition-shadow">
                  <CardContent className="p-4">
                    <div className="flex justify-between items-start mb-2">
                      <h4 className="font-semibold text-slate-900">{suggestion.title}</h4>
                      <Badge className={priorityMap[suggestion.priority]?.class || priorityMap.Medium.class}>
                        {suggestion.priority} Priority
                      </Badge>
                    </div>
                    <p className="text-sm text-slate-600 mb-4">{suggestion.reasoning}</p>
                    
                    {suggestion.document_type === 'civil_rights_complaint' ? (
                        <Link to={createPageUrl('CivilRightsComplaintBuilder')}>
                            <Button size="sm" className="gap-2">
                                <FileSignature className="w-4 h-4" />
                                Generate Document
                            </Button>
                        </Link>
                    ) : (
                        <Button size="sm" className="gap-2" onClick={() => onGenerate(suggestion.document_type)}>
                            <FileSignature className="w-4 h-4" />
                            Generate Document
                        </Button>
                    )}
                  </CardContent>
                </Card>
              ))
            ) : (
                <div className="text-center py-8 text-slate-500 bg-slate-50 rounded-lg">
                    <p>Enter your case summary above to get document recommendations.</p>
                </div>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}


import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { InvokeLLM } from "@/api/integrations";
import { useToast } from "@/components/ui/use-toast";
import { Loader2, Download, FileText } from "lucide-react";

export default function DocumentGenerator({ documentType, onBack }) {
    const [isGenerating, setIsGenerating] = useState(false);
    const [generatedDocument, setGeneratedDocument] = useState("");
    const [formData, setFormData] = useState({
        plaintiff_name: "",
        defendant_name: "",
        case_facts: "",
        relief_sought: "",
        jurisdiction: "",
        additional_details: ""
    });

    const { toast } = useToast();

    const documentPrompts = {
        motion_to_dismiss: `Draft a Motion to Dismiss based on the following information. Include proper legal citations and formatting for court filing.`,
        motion_compel: `Draft a Motion to Compel Discovery with proper legal citations and procedural requirements.`,
        discovery_request: `Draft comprehensive Discovery Requests (Interrogatories, Requests for Production, Requests for Admission) based on the case facts.`,
        affidavit: `Draft a detailed Affidavit of Facts with proper sworn statement language and notarization requirements.`,
        cease_desist: `Draft a professional Cease and Desist letter with legal basis and clear demands for cessation of unlawful activity.`,
        summary_judgment: `Draft a Motion for Summary Judgment with legal arguments and supporting case law citations.`,
        custody_agreement: `Draft a comprehensive Child Custody Agreement based on the provided details. Include clear sections for physical custody, legal custody, visitation schedules (including holidays and vacations), communication guidelines between parents, child support obligations, and a dispute resolution process (e.g., mediation). Ensure the language is formal and suitable for court filing or notarization.`,
        breach_of_contract_notice: `Draft a formal Breach of Contract Notice. The letter should clearly identify the contract, state the specific breach, demand a cure within a specific timeframe (e.g., 15 days), and state the consequences of failure to cure (e.g., legal action).`
    };

    const handleGenerate = async () => {
        if (!formData.case_facts.trim()) {
            toast({
                title: "Missing Information",
                description: "Please provide case facts to generate the document.",
                variant: "destructive"
            });
            return;
        }

        setIsGenerating(true);
        setGeneratedDocument(""); // Clear previous generated content

        try {
            const prompt = `${documentPrompts[documentType.id]}

Case Information:
- Plaintiff/Client: ${formData.plaintiff_name || "Client"}
- Defendant/Opposing Party: ${formData.defendant_name || "Opposing Party"}
- Jurisdiction: ${formData.jurisdiction || "Appropriate Court"}
- Case Facts: ${formData.case_facts}
- Relief Sought: ${formData.relief_sought}
- Additional Details: ${formData.additional_details}

Generate a professional, court-ready document with proper formatting, legal citations, and procedural requirements.`;

            const maxRetries = 3;
            let lastError = null;

            for (let attempt = 1; attempt <= maxRetries; attempt++) {
                try {
                    const result = await InvokeLLM({ prompt });
                    setGeneratedDocument(result);
                    toast({
                        title: "Document Generated",
                        description: "Your legal document is ready for review and download.",
                    });
                    setIsGenerating(false);
                    return; // Success, exit function
                } catch (error) {
                    lastError = error;
                    console.error(`Generation attempt ${attempt} failed:`, error);
                    if (attempt < maxRetries) {
                        const waitTime = Math.pow(2, attempt) * 1000; // Exponential back-off: 2s, 4s, 8s
                        toast({
                            title: `Attempt ${attempt} Failed`,
                            description: `Network issue detected. Retrying in ${waitTime / 1000} seconds...`,
                            variant: "destructive"
                        });
                        await new Promise(resolve => setTimeout(resolve, waitTime));
                    }
                }
            }
            throw lastError; // If loop finishes, all retries failed

        } catch (error) {
            console.error("Generation error:", error);
            let errorMessage = "Failed to generate document after multiple attempts. Please try again.";
            if (error && error.message && error.message.includes("Network Error")) {
                errorMessage = "A persistent network error occurred. Please check your connection and try again.";
            } else if (error && error.message) {
                errorMessage = `Generation failed: ${error.message}`;
            }
            toast({
                title: "Generation Failed",
                description: errorMessage,
                variant: "destructive"
            });
        } finally {
            setIsGenerating(false);
        }
    };

    const handleDownload = () => {
        if (!generatedDocument) return;
        
        const blob = new Blob([generatedDocument], { type: 'text/plain' });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `${documentType.title.replace(/[^a-zA-Z0-9]/g, '_')}.txt`;
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
        a.remove();
        
        toast({
            title: "Document Downloaded",
            description: "Your document has been downloaded as a text file.",
        });
    };

    return (
        <div className="space-y-6">
            <div className="flex items-center gap-3 mb-6">
                <div className="w-12 h-12 bg-gradient-to-br from-blue-600 to-slate-800 rounded-xl flex items-center justify-center">
                    <documentType.icon className="w-7 h-7 text-white" />
                </div>
                <div>
                    <h1 className="text-2xl font-bold text-slate-900">{documentType.title}</h1>
                    <p className="text-slate-600">{documentType.description}</p>
                </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <div className="space-y-6">
                    <Card className="border-0 shadow-lg bg-white">
                        <CardHeader>
                            <CardTitle>Document Information</CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-4">
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <div>
                                    <Label htmlFor="plaintiff_name">Your Name/Plaintiff</Label>
                                    <Input
                                        id="plaintiff_name"
                                        value={formData.plaintiff_name}
                                        onChange={(e) => setFormData({...formData, plaintiff_name: e.target.value})}
                                        placeholder="Enter your name"
                                    />
                                </div>
                                <div>
                                    <Label htmlFor="defendant_name">Opposing Party/Defendant</Label>
                                    <Input
                                        id="defendant_name"
                                        value={formData.defendant_name}
                                        onChange={(e) => setFormData({...formData, defendant_name: e.target.value})}
                                        placeholder="Enter opposing party name"
                                    />
                                </div>
                            </div>
                            
                            <div>
                                <Label htmlFor="jurisdiction">Court/Jurisdiction</Label>
                                <Input
                                    id="jurisdiction"
                                    value={formData.jurisdiction}
                                    onChange={(e) => setFormData({...formData, jurisdiction: e.target.value})}
                                    placeholder="e.g., U.S. District Court for the Southern District of NY"
                                />
                            </div>

                            <div>
                                <Label htmlFor="case_facts">Case Facts *</Label>
                                <Textarea
                                    id="case_facts"
                                    value={formData.case_facts}
                                    onChange={(e) => setFormData({...formData, case_facts: e.target.value})}
                                    placeholder="Provide detailed facts relevant to this document..."
                                    className="h-32"
                                />
                            </div>

                            <div>
                                <Label htmlFor="relief_sought">Relief Sought</Label>
                                <Textarea
                                    id="relief_sought"
                                    value={formData.relief_sought}
                                    onChange={(e) => setFormData({...formData, relief_sought: e.target.value})}
                                    placeholder="What outcome are you seeking?"
                                    className="h-20"
                                />
                            </div>

                            <div>
                                <Label htmlFor="additional_details">Additional Details</Label>
                                <Textarea
                                    id="additional_details"
                                    value={formData.additional_details}
                                    onChange={(e) => setFormData({...formData, additional_details: e.target.value})}
                                    placeholder="Any other relevant information..."
                                    className="h-20"
                                />
                            </div>

                            <div className="flex gap-3 pt-4">
                                <Button onClick={handleGenerate} disabled={isGenerating} className="flex-1">
                                    {isGenerating ? (
                                        <>
                                            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                            Generating...
                                        </>
                                    ) : (
                                        <>
                                            <FileText className="w-4 h-4 mr-2" />
                                            Generate Document
                                        </>
                                    )}
                                </Button>
                                <Button variant="outline" onClick={onBack}>
                                    Back
                                </Button>
                            </div>
                        </CardContent>
                    </Card>
                </div>

                <div>
                    <Card className="border-0 shadow-lg bg-white">
                        <CardHeader>
                            <div className="flex justify-between items-center">
                                <CardTitle>Generated Document</CardTitle>
                                {generatedDocument && (
                                    <Button variant="outline" size="sm" onClick={handleDownload}>
                                        <Download className="w-4 h-4 mr-2" />
                                        Download
                                    </Button>
                                )}
                            </div>
                        </CardHeader>
                        <CardContent>
                            {generatedDocument ? (
                                <div className="bg-slate-50 p-4 rounded-lg">
                                    <pre className="whitespace-pre-wrap text-sm text-slate-800 font-mono">
                                        {generatedDocument}
                                    </pre>
                                </div>
                            ) : (
                                <div className="text-center py-12 text-slate-500">
                                    <FileText className="w-12 h-12 mx-auto mb-4 text-slate-400" />
                                    <p>Fill out the form and click "Generate Document" to create your legal document.</p>
                                </div>
                            )}
                        </CardContent>
                    </Card>
                </div>
            </div>
        </div>
    );
}

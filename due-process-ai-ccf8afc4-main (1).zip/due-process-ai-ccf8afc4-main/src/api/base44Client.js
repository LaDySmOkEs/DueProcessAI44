import { createClient } from '@base44/sdk';
// import { getAccessToken } from '@base44/sdk/utils/auth-utils';

// Create a client with authentication required
export const base44 = createClient({
  appId: "6849c2e4b7247c9cccf8afc4", 
  requiresAuth: true // Ensure authentication is required for all operations
});

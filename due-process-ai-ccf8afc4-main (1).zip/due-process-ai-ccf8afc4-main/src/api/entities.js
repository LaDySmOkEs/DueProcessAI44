import { base44 } from './base44Client';


export const PoliceInteraction = base44.entities.PoliceInteraction;

export const KnowYourRightsModule = base44.entities.KnowYourRightsModule;

export const LegalCase = base44.entities.LegalCase;

export const LegalDocument = base44.entities.LegalDocument;

export const PoliceEncounter = base44.entities.PoliceEncounter;

export const FOIARequest = base44.entities.FOIARequest;

export const LitigationStrategy = base44.entities.LitigationStrategy;

export const DueProcessViolation = base44.entities.DueProcessViolation;

export const ClassActionPotential = base44.entities.ClassActionPotential;

export const DocumentCollection = base44.entities.DocumentCollection;

export const AnalyzedDocument = base44.entities.AnalyzedDocument;

export const ComplaintTracker = base44.entities.ComplaintTracker;



// auth sdk:
export const User = base44.auth;